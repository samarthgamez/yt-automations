from __future__ import annotations

import http.cookiejar
from unittest.mock import AsyncMock, MagicMock, Mock, patch

import httpx
import pytest

from app.library.httpx_client import (
    CFAsyncTransport,
    CFTransport,
    _get_transport,
    async_client,
    sync_client,
)


class TestGetTransport:
    def test_transport_custom_base_async(self):
        custom_transport = httpx.AsyncHTTPTransport()
        transport = _get_transport(enable_cf=True, is_async=True, transport=custom_transport)
        assert isinstance(transport, CFAsyncTransport)
        assert transport.base is custom_transport

    def test_transport_custom_base_sync(self):
        custom_transport = httpx.HTTPTransport()
        transport = _get_transport(enable_cf=True, is_async=False, transport=custom_transport)
        assert isinstance(transport, CFTransport)
        assert transport.base is custom_transport


class TestCFAsyncTransport:
    def setup_method(self):
        self.base_transport = AsyncMock(spec=httpx.AsyncHTTPTransport)
        self.transport = CFAsyncTransport(base=self.base_transport)

    @pytest.mark.asyncio
    async def test_init_custom(self):
        assert self.transport.base is self.base_transport

    @pytest.mark.asyncio
    @patch("app.library.httpx_client.is_cf_challenge")
    async def test_handle_request_no_challenge(self, mock_is_cf):
        mock_is_cf.return_value = False

        request = httpx.Request("GET", "https://example.com")
        response = Mock(status_code=200, headers={})
        self.base_transport.handle_async_request.return_value = response

        result = await self.transport.handle_async_request(request)

        assert result is response
        self.base_transport.handle_async_request.assert_called_once()
        mock_is_cf.assert_called_once_with(200, {})

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    async def test_handle_request_cached_solution(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = {
            "cookies": [{"name": "cf_clearance", "value": "token123"}],
            "userAgent": "Mozilla/5.0",
        }

        request = httpx.Request("GET", "https://example.com")
        response1 = Mock(status_code=403, headers={"Server": "cloudflare"})
        response1.aclose = AsyncMock()
        response2 = Mock(status_code=200, headers={})

        self.base_transport.handle_async_request.side_effect = [response1, response2]

        result = await self.transport.handle_async_request(request)

        assert result is response2
        assert 2 == self.base_transport.handle_async_request.call_count
        mock_solver.assert_called_once()
        response1.aclose.assert_called_once()

        second_call_request = self.base_transport.handle_async_request.call_args_list[1][0][0]
        assert "cf_clearance=token123" == second_call_request.headers["Cookie"]
        assert "Mozilla/5.0" == second_call_request.headers["User-Agent"]

    @pytest.mark.asyncio
    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    async def test_handle_request_solve_challenge(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = {
            "cookies": [{"name": "cf_clearance", "value": "token123"}, {"name": "__cf_bm", "value": "bm456"}],
            "userAgent": "Mozilla/5.0",
        }

        request = httpx.Request("GET", "https://example.com")
        response1 = Mock(status_code=403, headers={"cf-ray": "123"})
        response1.aclose = AsyncMock()
        response2 = Mock(status_code=200, headers={})

        self.base_transport.handle_async_request.side_effect = [response1, response2]

        result = await self.transport.handle_async_request(request)

        assert result is response2
        assert 2 == self.base_transport.handle_async_request.call_count
        mock_solver.assert_called_once()
        response1.aclose.assert_called_once()

        second_call_request = self.base_transport.handle_async_request.call_args_list[1][0][0]
        assert "cf_clearance=token123; __cf_bm=bm456" == second_call_request.headers["Cookie"]
        assert "Mozilla/5.0" == second_call_request.headers["User-Agent"]

    @pytest.mark.asyncio
    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    async def test_merge_existing_cookies(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = {
            "cookies": [{"name": "cf_clearance", "value": "token123"}],
            "userAgent": "Mozilla/5.0",
        }

        request = httpx.Request("GET", "https://example.com", cookies={"session_id": "abc123", "user_pref": "dark"})
        response1 = Mock(status_code=403, headers={"cf-ray": "123"})
        response1.aclose = AsyncMock()
        response2 = Mock(status_code=200, headers={})

        self.base_transport.handle_async_request.side_effect = [response1, response2]

        result = await self.transport.handle_async_request(request)

        assert result is response2

        second_call_request = self.base_transport.handle_async_request.call_args_list[1][0][0]
        cookie_header = second_call_request.headers["Cookie"]
        assert "session_id=abc123" in cookie_header
        assert "user_pref=dark" in cookie_header
        assert "cf_clearance=token123" in cookie_header

    @pytest.mark.asyncio
    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    async def test_handle_request_solve_failed(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = None

        request = httpx.Request("GET", "https://example.com")
        response = Mock(status_code=403, headers={"cf-ray": "123"})
        response.close = Mock()

        self.base_transport.handle_async_request.return_value = response

        result = await self.transport.handle_async_request(request)

        assert result is response
        assert 1 == self.base_transport.handle_async_request.call_count
        mock_solver.assert_called_once()
        response.close.assert_not_called()

    def test_close(self):
        self.base_transport.close = Mock()
        self.transport.close()
        self.base_transport.close.assert_called_once()


class TestCFTransport:
    def setup_method(self):
        self.base_transport = Mock(spec=httpx.HTTPTransport)
        self.transport = CFTransport(base=self.base_transport)

    def test_init_custom(self):
        assert self.transport.base is self.base_transport

    @patch("app.library.httpx_client.is_cf_challenge")
    def test_handle_request_no_challenge(self, mock_is_cf):
        mock_is_cf.return_value = False

        request = httpx.Request("GET", "https://example.com")
        response = Mock(status_code=200, headers={})
        self.base_transport.handle_request.return_value = response

        result = self.transport.handle_request(request)

        assert result is response
        self.base_transport.handle_request.assert_called_once()
        mock_is_cf.assert_called_once_with(200, {})

    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    def test_handle_request_cached_solution(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = {
            "cookies": [{"name": "cf_clearance", "value": "token123"}],
            "userAgent": "Mozilla/5.0",
        }

        request = httpx.Request("GET", "https://example.com")
        response1 = Mock(status_code=403, headers={"Server": "cloudflare"})
        response1.close = Mock()
        response2 = Mock(status_code=200, headers={})

        self.base_transport.handle_request.side_effect = [response1, response2]

        result = self.transport.handle_request(request)

        assert result is response2
        assert 2 == self.base_transport.handle_request.call_count
        mock_solver.assert_called_once()
        response1.close.assert_called_once()

        second_call_request = self.base_transport.handle_request.call_args_list[1][0][0]
        assert "cf_clearance=token123" == second_call_request.headers["Cookie"]
        assert "Mozilla/5.0" == second_call_request.headers["User-Agent"]

    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    def test_handle_request_solve_challenge(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = {
            "cookies": [{"name": "cf_clearance", "value": "token123"}, {"name": "__cf_bm", "value": "bm456"}],
            "userAgent": "Mozilla/5.0",
        }

        request = httpx.Request("GET", "https://example.com")
        response1 = Mock(status_code=503, headers={"cf-cache-status": "DYNAMIC"})
        response1.close = Mock()
        response2 = Mock(status_code=200, headers={})

        self.base_transport.handle_request.side_effect = [response1, response2]

        result = self.transport.handle_request(request)

        assert result is response2
        assert 2 == self.base_transport.handle_request.call_count
        mock_solver.assert_called_once()
        response1.close.assert_called_once()

        second_call_request = self.base_transport.handle_request.call_args_list[1][0][0]
        assert "cf_clearance=token123; __cf_bm=bm456" == second_call_request.headers["Cookie"]
        assert "Mozilla/5.0" == second_call_request.headers["User-Agent"]

    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    def test_request_merge_existing_cookies(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = {
            "cookies": [{"name": "cf_clearance", "value": "token123"}],
            "userAgent": "Mozilla/5.0",
        }

        request = httpx.Request("GET", "https://example.com", cookies={"session_id": "abc123", "user_pref": "dark"})
        response1 = Mock(status_code=403, headers={"cf-ray": "123"})
        response1.close = Mock()
        response2 = Mock(status_code=200, headers={})

        self.base_transport.handle_request.side_effect = [response1, response2]

        result = self.transport.handle_request(request)

        assert result is response2

        second_call_request = self.base_transport.handle_request.call_args_list[1][0][0]
        cookie_header = second_call_request.headers["Cookie"]
        assert "session_id=abc123" in cookie_header
        assert "user_pref=dark" in cookie_header
        assert "cf_clearance=token123" in cookie_header

    @patch("app.library.httpx_client.solver")
    @patch("app.library.httpx_client.is_cf_challenge")
    def test_handle_request_solve_failed(self, mock_is_cf, mock_solver):
        mock_is_cf.return_value = True
        mock_solver.return_value = None

        request = httpx.Request("GET", "https://example.com")
        response = Mock(status_code=429, headers={"cf-ray": "abc123"})
        response.close = Mock()

        self.base_transport.handle_request.return_value = response

        result = self.transport.handle_request(request)

        assert result is response
        assert 1 == self.base_transport.handle_request.call_count
        mock_solver.assert_called_once()
        response.close.assert_not_called()

    def test_close(self):
        self.base_transport.close = Mock()
        self.transport.close()
        self.base_transport.close.assert_called_once()


class TestAsyncClient:
    @pytest.mark.asyncio
    async def test_async_client_cf_enabled(self):
        async with async_client(enable_cf=True) as client:
            assert isinstance(client, httpx.AsyncClient)
            assert isinstance(client._transport, CFAsyncTransport)

    @pytest.mark.asyncio
    async def test_client_custom_cf_off(self):
        async with async_client(enable_cf=False) as client:
            assert isinstance(client, httpx.AsyncClient)
            assert isinstance(client._transport, httpx.AsyncHTTPTransport)

    @pytest.mark.asyncio
    async def test_async_client_kwargs(self):
        async with async_client(enable_cf=True, timeout=30.0, follow_redirects=True) as client:
            assert isinstance(client, httpx.AsyncClient)
            assert isinstance(client._transport, CFAsyncTransport)
            assert 30.0 == client.timeout.read
            assert client.follow_redirects is True

    @pytest.mark.asyncio
    async def test_async_client_custom_transport(self):
        custom = httpx.AsyncHTTPTransport()
        async with async_client(enable_cf=True, transport=custom) as client:
            assert isinstance(client, httpx.AsyncClient)
            assert isinstance(client._transport, CFAsyncTransport)
            assert client._transport.base is custom

    @pytest.mark.asyncio
    async def test_async_client_cf_disabled(self):
        custom = httpx.AsyncHTTPTransport()
        async with async_client(enable_cf=False, transport=custom) as client:
            assert isinstance(client, httpx.AsyncClient)

            assert client._transport is custom


class TestSyncClient:
    def test_sync_client_cf_enabled(self):
        with sync_client(enable_cf=True) as client:
            assert isinstance(client, httpx.Client)
            assert isinstance(client._transport, CFTransport)

    def test_custom_cf_off(self):
        with sync_client(enable_cf=False) as client:
            assert isinstance(client, httpx.Client)
            assert isinstance(client._transport, httpx.HTTPTransport)

    def test_sync_client_kwargs(self):
        with sync_client(enable_cf=True, timeout=30.0, follow_redirects=True) as client:
            assert isinstance(client, httpx.Client)
            assert isinstance(client._transport, CFTransport)
            assert 30.0 == client.timeout.read
            assert client.follow_redirects is True

    def test_sync_client_custom_transport(self):
        custom = httpx.HTTPTransport()
        with sync_client(enable_cf=True, transport=custom) as client:
            assert isinstance(client, httpx.Client)
            assert isinstance(client._transport, CFTransport)
            assert client._transport.base is custom

    def test_sync_client_cf_disabled(self):
        custom = httpx.HTTPTransport()
        with sync_client(enable_cf=False, transport=custom) as client:
            assert isinstance(client, httpx.Client)
            assert client._transport is custom, "When CF is disabled, custom transport should be used directly"
