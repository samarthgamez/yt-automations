import ipaddress
import json
import logging
import os
import re
import shutil
import sys
import time
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from dotenv import load_dotenv

from app.library.logging import get_logger, get_runtime_log_level, setup_logging
from app.library.Utils import resolve_secret

from .Singleton import Singleton
from .version import APP_BRANCH, APP_BUILD_DATE, APP_COMMIT_SHA, APP_VERSION

APP_THIRD_PARTY_LOG_LEVELS: tuple[tuple[str, int], ...] = (
    ("httpx", logging.WARNING),
    ("urllib3.connectionpool", logging.WARNING),
    ("apprise", logging.WARNING),
    ("httpcore", logging.INFO),
    ("aiosqlite", logging.INFO),
    ("asyncio", logging.INFO),
)

if TYPE_CHECKING:
    from subprocess import CompletedProcess

SUPPORTED_CODECS: tuple[str, ...] = ("h264_qsv", "h264_nvenc", "h264_amf", "h264_videotoolbox", "h264_vaapi", "libx264")

_HTTP_TOKEN: re.Pattern[str] = re.compile(r"^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$")


@dataclass(frozen=True, kw_only=True)
class OidcConfig:
    issuer: str
    client_id: str
    client_secret: str
    redirect_uri: str


@dataclass(frozen=True, kw_only=True)
class RemoteUserConfig:
    enabled: bool
    header: str
    trusted_proxies: tuple[ipaddress.IPv4Network | ipaddress.IPv6Network, ...]


@dataclass(frozen=True, kw_only=True)
class ExternalAuthConfig:
    external_user: str | None
    oidc: OidcConfig | None
    remote_user: RemoteUserConfig


def _external_auth_config(config_path: str) -> ExternalAuthConfig:
    path = Path(config_path) / "config.toml"
    if not path.exists():
        data: dict[str, object] = {}
    else:
        try:
            with path.open("rb") as file:
                data = tomllib.load(file)
        except tomllib.TOMLDecodeError as exc:
            msg = "Invalid config.toml TOML"
            raise ValueError(msg) from exc

    auth = data.get("auth", {})
    if not isinstance(auth, dict):
        msg = "auth must be a table"
        raise ValueError(msg)

    external_user = auth.get("external_user")
    if external_user is not None and (not isinstance(external_user, str) or not external_user.strip()):
        msg = "auth.external_user must be a non-empty string"
        raise ValueError(msg)

    if isinstance(external_user, str):
        external_user = external_user.strip()

    oidc_data = auth.get("oidc")
    oidc = None
    if oidc_data is not None:
        if not isinstance(oidc_data, dict):
            msg = "auth.oidc must be a table"
            raise ValueError(msg)

        values = {
            key: value.strip() if isinstance(value := oidc_data.get(key), str) else value
            for key in ("issuer", "client_id", "client_secret", "redirect_uri")
        }

        if any(not isinstance(value, str) or not value for value in values.values()):
            msg = "auth.oidc requires non-empty issuer, client_id, client_secret, and redirect_uri"
            raise ValueError(msg)

        for key in ("client_id", "client_secret"):
            values[key] = resolve_secret(values[key], base_dir=path.parent)

        oidc = OidcConfig(**values)

    remote_data = auth.get("remote_user", {})
    if not isinstance(remote_data, dict):
        msg = "auth.remote_user must be a table"
        raise ValueError(msg)

    enabled = remote_data.get("enabled", False)
    if not isinstance(enabled, bool):
        msg = "auth.remote_user.enabled must be a boolean"
        raise ValueError(msg)

    header = remote_data.get("header", "Remote-User")
    if not isinstance(header, str) or not (header := header.strip()) or not _HTTP_TOKEN.fullmatch(header):
        msg = "auth.remote_user.header must be a valid HTTP token"
        raise ValueError(msg)

    proxies = remote_data.get("trusted_proxies", [])
    if not isinstance(proxies, list) or not all(isinstance(proxy, str) for proxy in proxies):
        msg = "auth.remote_user.trusted_proxies must be an array"
        raise ValueError(msg)

    try:
        trusted_proxies = tuple(ipaddress.ip_network(value) for value in proxies)
    except (ValueError, TypeError):
        msg = "auth.remote_user.trusted_proxies must contain valid CIDRs"
        raise ValueError(msg) from None

    if enabled and not trusted_proxies:
        msg = "enabled auth.remote_user requires trusted_proxies"
        raise ValueError(msg)

    if (oidc is not None or enabled) and not external_user:
        msg = "auth.external_user is required when external authentication is enabled"
        raise ValueError(msg)

    return ExternalAuthConfig(
        external_user=external_user,
        oidc=oidc,
        remote_user=RemoteUserConfig(enabled=enabled, header=header, trusted_proxies=trusted_proxies),
    )


def native_defaults() -> dict[str, Any]:
    import platformdirs

    return {
        "config_path": platformdirs.user_config_dir("ytptube", "arabcoders"),
        "temp_path": platformdirs.user_cache_dir("ytptube", "arabcoders"),
        "download_path": platformdirs.user_downloads_dir(),
        "host": "127.0.0.1",
        "access_log": False,
        "disable_auth": True,
        "cors_origins": "",
        "debugpy_host": "127.0.0.1",
    }


class Config(metaclass=Singleton):
    external_auth: ExternalAuthConfig

    app_env: str = "production"
    """The application environment, can be 'production' or 'development'."""

    app_path: str = "../../"
    """The app path of the application."""

    config_path: str = "."
    """The path to the configuration directory."""

    download_path: str = "."
    """The path to the download directory."""

    download_info_expires: int = 10800
    """How long (in seconds) the download info is valid before it needs to be re-extracted."""

    retry: int = 0
    """Number of additional attempts allowed for retryable download failures."""

    retry_fresh: bool = False
    """Use a fresh download on the final retry attempt."""

    temp_path: str = "/tmp"
    """The path to the temporary directory."""

    simple_mode: bool = False
    """Enable simple mode."""

    temp_keep: bool = False
    """Keep temporary files after the download is complete."""

    temp_disabled: bool = False
    """Disable the temporary files feature."""

    output_template: str = "%(title)s.%(ext)s"
    """The output template to use for the downloaded files."""

    output_template_chapter: str = "%(title)s - %(section_number)s %(section_title)s.%(ext)s"
    """The output template to use for the downloaded files with chapters."""

    filename_trim: str = ""
    """Where to remove filename content when it exceeds the filesystem limit."""

    filename_trim_regexes: tuple[re.Pattern[str], ...] = ()
    """Patterns matching filename content that must not be removed."""

    keep_archive: bool = True
    """Keep the download archive file."""

    host: str = "0.0.0.0"
    """The host to bind the server to."""

    port: int = 8081
    """The port to bind the server to."""

    log_level: str = "info"
    """The log level to use for the application."""

    base_path: str = "/"
    """The base path to use for the application."""

    max_workers: int = 20
    """The maximum number of workers to use for downloading."""

    max_workers_per_extractor: int = 2
    """The maximum number of concurrent downloads per extractor."""

    streamer_vcodec: str = ""
    """The video codec to use for streaming. If empty, auto-detect."""

    streamer_acodec: str = "aac"
    """The audio codec to use for streaming."""

    vaapi_device: str = "/dev/dri/renderD128"
    """VAAPI device path used for VAAPI encoder when available."""

    auth_username: str | None = None
    """The username for bootstrapping the initial account."""

    auth_password: str | None = None
    """The password for bootstrapping the initial account."""

    auth_session_days: int = 30
    """The number of days to keep authentication sessions active."""

    disable_auth: bool = False
    """Disable application authentication."""

    cors_origins: str = "*"
    """Allowed CORS origins."""

    trusted_proxies: str = ""
    """Comma-separated trusted proxy IP addresses or CIDRs."""

    remove_files: bool = False
    """Remove downloaded files when removing the record."""

    access_log: bool = True
    """Enable access logging."""

    no_browser: bool = False
    """Prevent native builds from opening the browser on startup."""

    debug: bool = False
    """Enable debugging."""

    debugpy_port: int = 5678
    """The port to use for the debugpy server."""

    debugpy_host: str = "0.0.0.0"
    """The host to use for the debugpy server."""

    extract_info_timeout: int = 70
    """The timeout to use for extracting video information."""

    extract_info_concurrency: int = 4
    """The number of concurrent extract_info calls allowed."""

    extract_info_keep_alive: bool = False
    """Keep extract_info worker processes alive between requests."""

    thumb_concurrency: int = 2
    """The number of concurrent ffmpeg thumbnail generations allowed."""

    thumb_generate: bool = True
    """Enable ffmpeg thumbnail generation when no local thumbnail exists."""

    thumb_sidecar: bool = False
    """Save generated thumbnails next to the media file instead of temp cache."""

    db_file: str = "{config_path}{os_sep}ytptube.db"
    """The path to the database file."""

    archive_file: str = "{config_path}{os_sep}archive.log"
    """The path to the download archive file."""

    apprise_config: str = "{config_path}{os_sep}apprise.yml"
    """The path to the Apprise configuration file."""

    pip_packages: str = ""
    """The pip packages to install."""

    pip_ignore_updates: bool = False
    """Ignore pip package updates."""

    app_version: str = APP_VERSION
    "The version of the application, same as `version`."

    app_commit_sha: str = APP_COMMIT_SHA
    "The commit SHA of the application."

    app_build_date: str = APP_BUILD_DATE
    "The build date of the application."

    app_branch: str = APP_BRANCH
    "The branch of the application."

    started: int = 0
    "The time the application was started."

    ignore_ui: bool = False
    "Ignore the UI and run the application in the background."

    default_preset: str = "default"
    "The default preset to use when no preset is specified."

    instance_title: str | None = None
    "The title of the instance."

    file_logging: bool = True
    "Enable file logging."

    tasks_handler_timer: str = "15 */1 * * *"
    """The cron expression for the tasks timer."""

    console_enabled: bool = False
    "Enable direct access to yt-dlp console."

    browser_control_enabled: bool = False
    "Enable file browser control access."

    ytdlp_auto_update: bool = True
    """Enable in-place auto update of yt-dlp package."""

    ytdlp_version: str | None = None
    """The version of yt-dlp to use, if not set, the latest version will be used."""

    ytdlp_debug: bool = False
    """Enable yt-dlp debugging."""

    flaresolverr_url: str = ""
    """FlareSolverr endpoint URL."""

    flaresolverr_max_timeout: int = 120
    """Max FlareSolverr challenge timeout in seconds."""

    flaresolverr_client_timeout: int = 120
    """HTTP client timeout (seconds) when calling FlareSolverr."""

    flaresolverr_cache_ttl: int = 600
    """The cache TTL (in seconds) for FlareSolverr solutions."""

    is_native: bool = False
    "Is the application running in natively."

    prevent_live_premiere: bool = True
    """Prevent downloading of the initial premiere live broadcast."""

    live_premiere_buffer: int = 5
    """The buffer time in minutes to add to video duration to wait before starting premiere download."""

    auto_clear_history_days: int = 0
    """Number of days after which completed download history is automatically cleared. 0 to disable."""

    default_pagination: int = 50
    """The default number of items per page for pagination."""

    queue_display_limit: int = 100
    """Maximum number of queued downloads returned to the UI. 0 means unlimited."""

    task_handler_random_delay: float = 60.0
    """The maximum random delay in seconds before starting a task handler."""

    ignore_archived_items: bool = False
    """Dont report archived items in the download history."""

    pictures_backends: list[str] = [
        "https://unsplash.it/1920/1080?random",
        "https://picsum.photos/1920/1080",
        "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-US",
    ]
    "The list of picture backends to use for the background."

    static_ui_path: str = ""
    "The path to the static UI files."

    check_for_updates: bool = True
    "Check for application updates."

    new_version: str = ""
    "The new version available."

    yt_new_version: str = ""
    "The new yt-dlp version available."

    monitor_enabled: bool = False
    "Enable app resource monitoring."

    monitor_interval: int = 30
    "Sampling interval in seconds for app resource monitoring."

    monitor_retention_hours: int = 24
    "How many hours to retain raw monitor samples in the stats database."

    _manual_vars: tuple = (
        "temp_path",
        "config_path",
        "download_path",
        "app_path",
        "external_auth",
    )
    "The variables that are set manually."

    _immutable: tuple = (
        "ytdl_options",
        "started",
        "is_native",
        "app_version",
        "app_commit_sha",
        "app_build_date",
        "app_branch",
        "new_version",
        "yt_new_version",
    )
    "The variables that are immutable."

    _int_vars: tuple = (
        "port",
        "max_workers",
        "max_workers_per_extractor",
        "extract_info_timeout",
        "debugpy_port",
        "download_info_expires",
        "retry",
        "auto_clear_history_days",
        "default_pagination",
        "queue_display_limit",
        "extract_info_concurrency",
        "thumb_concurrency",
        "flaresolverr_max_timeout",
        "flaresolverr_client_timeout",
        "flaresolverr_cache_ttl",
        "monitor_interval",
        "monitor_retention_hours",
        "auth_session_days",
    )
    "The variables that are integers."

    _boolean_vars: tuple = (
        "keep_archive",
        "ytdlp_debug",
        "debug",
        "temp_keep",
        "access_log",
        "no_browser",
        "remove_files",
        "ignore_ui",
        "pip_ignore_updates",
        "file_logging",
        "console_enabled",
        "browser_control_enabled",
        "ytdlp_auto_update",
        "prevent_live_premiere",
        "temp_disabled",
        "retry_fresh",
        "simple_mode",
        "ignore_archived_items",
        "check_for_updates",
        "thumb_generate",
        "thumb_sidecar",
        "disable_auth",
        "extract_info_keep_alive",
        "monitor_enabled",
    )
    "The variables that are booleans."

    _float_vars: tuple = ("task_handler_random_delay",)
    "The variables that are floats."

    _frontend_vars: tuple = (
        "download_path",
        "keep_archive",
        "log_level",
        "output_template",
        "started",
        "remove_files",
        "max_workers",
        "max_workers_per_extractor",
        "default_preset",
        "instance_title",
        "console_enabled",
        "simple_mode",
        "browser_control_enabled",
        "file_logging",
        "base_path",
        "is_native",
        "app_env",
        "tasks_handler_timer",
        "app_version",
        "app_commit_sha",
        "app_build_date",
        "app_branch",
        "default_pagination",
        "queue_display_limit",
        "retry",
        "retry_fresh",
        "check_for_updates",
        "new_version",
        "yt_new_version",
        "monitor_enabled",
    )
    "The variables that are relevant to the frontend."

    os_sep: str = os.path.sep
    "The system path separator."

    @staticmethod
    def get_instance(is_native: bool | None = None) -> "Config":
        instance = Config(is_native is True)
        if is_native is not None and instance.is_native is not is_native:
            msg = "Config is already initialized for a different runtime mode."
            raise RuntimeError(msg)
        return instance

    def __init__(self, is_native: bool = False):
        baseDefaultPath: str = str(Path(__file__).parent.parent.parent.absolute())
        LOG = get_logger()
        runtime_defaults = native_defaults() if is_native else {}

        self.config_path = os.environ.get("YTP_CONFIG_PATH", None) or runtime_defaults.get(
            "config_path", str(Path(baseDefaultPath) / "var" / "config")
        )
        self.external_auth = _external_auth_config(self.config_path)
        envFile: Path = Path(self.config_path) / ".env"

        if envFile.exists():
            LOG.info("Loading environment variables from '%s'.", envFile)
            load_dotenv(envFile)

        self.is_native = is_native
        self.temp_path = os.environ.get("YTP_TEMP_PATH", None) or runtime_defaults.get(
            "temp_path", str(Path(baseDefaultPath) / "var" / "tmp")
        )
        self.download_path = os.environ.get("YTP_DOWNLOAD_PATH", None) or runtime_defaults.get(
            "download_path", str(Path(baseDefaultPath) / "var" / "downloads")
        )
        self.app_path = str(Path(__file__).parent.parent.absolute())

        for k, v in self._get_attributes().items():
            if k.startswith("_") or k in self._manual_vars:
                continue

            # If the variable declared as immutable, set it to the default value.
            if k in self._immutable:
                setattr(self, k, v)
                continue

            lookUpKey: str = f"YTP_{k}".upper()
            default = runtime_defaults.get(k, v)
            setattr(self, k, os.environ.get(lookUpKey, default))

        self.is_native = is_native

        for k, v in self.__dict__.items():
            if k.startswith("_") or k in self._immutable or k in self._manual_vars:
                continue

            if isinstance(v, str) and "{" in v and "}" in v:
                for key in re.findall(r"\{.*?\}", v):
                    localKey: str = key[1:-1]
                    if localKey not in self.__dict__:
                        LOG.error("Config variable '%s' had non-existing config reference '%s'.", k, key)
                        sys.exit(1)

                    v: str = v.replace(key, str(getattr(self, localKey)))

                setattr(self, k, v)

            if k in self._boolean_vars:
                if str(v).lower() not in (True, False, "true", "false", "on", "off", "1", "0"):
                    msg = f"Config variable '{k}' is set to a non-boolean value '{v}'."
                    raise ValueError(msg)

                setattr(self, k, str(v).lower() in (True, "true", "on", "1"))

            if k in self._int_vars:
                setattr(self, k, int(v))
                if k == "auth_session_days" and self.auth_session_days < 1:
                    msg = "Config variable 'auth_session_days' must be at least 1."
                    raise ValueError(msg)

            if k in self._float_vars:
                setattr(self, k, float(v))

        if isinstance(self.pictures_backends, str) and self.pictures_backends:
            self.pictures_backends = self.pictures_backends.split(",")

        self.filename_trim = self.filename_trim.strip().lower()
        if self.filename_trim not in ("", "start", "middle", "end"):
            msg = "Config variable 'filename_trim' must be empty, 'start', 'middle', or 'end'."
            raise ValueError(msg)

        if isinstance(self.filename_trim_regexes, str):
            try:
                patterns = json.loads(self.filename_trim_regexes)
            except json.JSONDecodeError as e:
                msg = "Config variable 'filename_trim_regexes' must be a JSON array of regular expressions."
                raise ValueError(msg) from e
        else:
            patterns = self.filename_trim_regexes

        if not isinstance(patterns, (list, tuple)) or any(not isinstance(pattern, str) for pattern in patterns):
            msg = "Config variable 'filename_trim_regexes' must be a JSON array of regular expressions."
            raise ValueError(msg)

        compiled_patterns: list[re.Pattern[str]] = []
        for index, pattern in enumerate(patterns):
            try:
                compiled_patterns.append(re.compile(pattern))
            except re.error as e:
                msg = f"Invalid filename trim regular expression at index {index}: {e!s}"
                raise ValueError(msg) from e

        self.filename_trim_regexes = tuple(compiled_patterns)

        if not self.base_path.endswith("/"):
            self.base_path += "/"

        try:
            setup_logging(
                level=self.log_level,
                log_path=Path(self.config_path) / "logs" / "app.jsonl" if self.file_logging else None,
                third_party_levels=APP_THIRD_PARTY_LOG_LEVELS,
            )
        except ValueError as e:
            msg = f"Invalid log level '{self.log_level}' specified."
            raise TypeError(msg) from e

        if self.debug:
            try:
                import debugpy

                debugpy.listen((self.debugpy_host, self.debugpy_port), in_process_debug_adapter=True)
                LOG.warning(
                    "Debugpy started on '%s:%s'. insecure debugger allows remote code execution, use only in a secure environment.",
                    self.debugpy_host,
                    self.debugpy_port,
                    extra={"host": self.debugpy_host, "port": self.debugpy_port},
                )
            except ImportError:
                LOG.error("debugpy package not found; install it with 'uv sync'.")
            except Exception as e:
                LOG.exception(
                    "Failed to start debugpy server.",
                    extra={"host": self.debugpy_host, "port": self.debugpy_port, "exception_type": type(e).__name__},
                )

        if (Path(self.config_path) / "ytdlp.cli").exists():
            LOG.error("Support for ./ytdlp.cli file is removed, migrate to presets and remove the file.")

        if self.temp_keep:
            LOG.warning("Keep temp files option is enabled.")

        self.started = int(time.time())

        if self.app_env not in ("production", "development"):
            msg: str = f"Invalid app environment '{self.app_env}' specified. Must be 'production' or 'development'."
            raise ValueError(msg)

        if self.streamer_vcodec and self.streamer_vcodec not in SUPPORTED_CODECS:
            supported = ", ".join(SUPPORTED_CODECS)
            msg: str = f"Invalid video codec '{self.streamer_vcodec}' specified. Supported: '{supported}'."
            raise ValueError(msg)

        if "dev-master" == self.app_version:
            self._version_via_git()

    def set_app_path(self, path: Path | str) -> "Config":
        """
        Set the root path of the application.

        Args:
            path (str): The root path to set.

        Returns:
            Config: The Config instance.

        """
        Config.app_path = str(path)

        return self

    def _get_attributes(self) -> dict:
        attrs: dict = {}
        vClass: type = self.__class__

        for attribute in vClass.__dict__:
            if attribute.startswith("_"):
                continue

            value: Any = getattr(vClass, attribute)
            if not callable(value):
                attrs[attribute] = value

        return attrs

    def is_dev(self) -> bool:
        """
        Check if the application is running in development mode.

        Returns:
            bool: True if the application is in development mode, False otherwise.

        """
        return "development" == self.app_env

    def is_prod(self) -> bool:
        """
        Check if the application is running in production mode.

        Returns:
            bool: True if the application is in production mode, False otherwise.

        """
        return "production" == self.app_env

    def frontend(self) -> dict:
        """
        Returns configuration variables relevant to the frontend.

        Returns:
            dict: A dictionary with the frontend configuration

        """
        data: dict[str, Any] = {k: getattr(self, k) for k in self._frontend_vars}

        data["ytdlp_version"] = Config._ytdlp_version()
        data["runtime_log_level"] = get_runtime_log_level()
        return data

    def get_replacers(self) -> dict[str, str]:
        """
        Get the variables that can be used in Command options for yt-dlp.

        Returns:
            dict[str, str]: The replacer variables.

        """
        keys: tuple[str, ...] = ("os_sep", "download_path", "temp_path", "config_path", "archive_file")
        return {k: getattr(self, k) for k in keys}

    @staticmethod
    def _ytdlp_version() -> str:
        try:
            from yt_dlp.version import __version__ as YTDLP_VERSION

            return YTDLP_VERSION
        except ImportError:
            return "0.0.0"

    def _version_via_git(self):
        """
        Updates the version of the application using git tags.
        This is used to set the version to the latest git tag.
        """
        LOG = get_logger()
        git_path: Path = Path(__file__).parent / ".." / ".." / ".git"
        if not git_path.exists():
            return

        try:
            import subprocess

            git = shutil.which("git")
            if not git:
                LOG.warning("Git executable was not found.")
                return

            branch_result: CompletedProcess[str] = subprocess.run(
                [git, "-c", f"safe.directory={git_path.parent!s}", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=os.path.dirname(git_path),
                capture_output=True,
                text=True,
                check=False,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )

            if 0 != branch_result.returncode:
                LOG.error("Git rev-parse failed: %s", branch_result.stderr.strip())
                return

            branch_name: str = branch_result.stdout.strip()
            if not branch_name:
                LOG.warning("Git branch name is empty.")
                return

            commit_result: CompletedProcess[str] = subprocess.run(
                [git, "-c", f"safe.directory={git_path.parent!s}", "log", "-1", "--format=%ct_%H"],
                cwd=os.path.dirname(git_path),
                capture_output=True,
                text=True,
                check=False,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )

            if 0 != commit_result.returncode:
                LOG.error("Git log failed: %s", commit_result.stderr.strip())
                return

            commit_info: str = commit_result.stdout.strip()
            if not commit_info:
                LOG.warning("Git commit info is empty.")
                return

            commit_date, commit_sha = commit_info.split("_", 1)
            commit_date: str = time.strftime("%Y%m%d", time.localtime(int(commit_date)))

            self.app_version = f"{branch_name}-{commit_date}-{commit_sha[:8]}"
            self.app_branch = branch_name
            self.app_commit_sha = commit_sha
            self.app_build_date = commit_date
        except Exception as e:
            LOG.error("Error while getting git version: %s", e)
