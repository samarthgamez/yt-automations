"""Presets feature module."""
