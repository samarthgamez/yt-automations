from __future__ import annotations

import pytest
import pytest_asyncio

from app.features.dl_fields.repository import DLFieldsRepository
from app.features.dl_fields.service import DLFields
from app.library.sqlite_store import SqliteStore
from app.tests.helpers import make_in_memory_db_path


@pytest_asyncio.fixture
async def repo():
    """Provide a fresh repository instance with initialized database for each test."""
    DLFieldsRepository._reset_singleton()
    DLFields._reset_singleton()
    SqliteStore._reset_singleton()

    store = SqliteStore(db_path=make_in_memory_db_path("dl-fields-service"))
    await store.get_connection()

    repository = DLFieldsRepository.get_instance()

    yield repository

    await store.close()

    DLFieldsRepository._reset_singleton()
    DLFields._reset_singleton()
    SqliteStore._reset_singleton()


class TestDLFieldsService:
    @pytest.mark.asyncio
    async def test_save_creates_field(self, repo):
        """Save should create a new dl field when ID is missing."""
        service = DLFields.get_instance()
        payload = {
            "name": "quality",
            "description": "Video quality",
            "field": "--format",
            "kind": "string",
            "order": 1,
            "extras": {"options": ["best", "worst"]},
        }

        model = await service.save(payload)

        assert model.id is not None
        assert model.name == "quality"

    @pytest.mark.asyncio
    async def test_get_all_serialized(self, repo):
        service = DLFields.get_instance()
        await service.save(
            {
                "name": "audio_only",
                "description": "Audio",
                "field": "--extract-audio",
                "kind": "bool",
                "order": 2,
            }
        )

        items = await service.get_all_serialized()

        assert len(items) == 1
        assert items[0]["name"] == "audio_only"
        assert isinstance(items[0]["id"], int)
