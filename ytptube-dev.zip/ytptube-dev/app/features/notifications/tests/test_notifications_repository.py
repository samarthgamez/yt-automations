from __future__ import annotations

import pytest
import pytest_asyncio

from app.features.notifications.repository import NotificationsRepository
from app.library.sqlite_store import SqliteStore
from app.tests.helpers import make_in_memory_db_path


@pytest_asyncio.fixture
async def repo():
    """Provide a fresh repository instance with initialized database for each test."""
    NotificationsRepository._reset_singleton()
    SqliteStore._reset_singleton()

    store = SqliteStore(db_path=make_in_memory_db_path("notifications-repository"))
    await store.get_connection()

    repository = NotificationsRepository.get_instance()

    yield repository

    await store.close()

    NotificationsRepository._reset_singleton()
    SqliteStore._reset_singleton()


class TestNotificationsRepository:
    @pytest.mark.asyncio
    async def test_list_empty(self, repo):
        """List returns empty when no notifications exist."""
        notifications = await repo.all()
        assert notifications == []

    @pytest.mark.asyncio
    async def test_create_notification(self, repo):
        payload = {
            "name": "Webhook",
            "on": ["item_completed"],
            "presets": [],
            "enabled": True,
            "request_url": "https://example.com/webhook",
            "request_method": "POST",
            "request_type": "json",
            "request_data_key": "data",
            "request_headers": [{"key": "Authorization", "value": "Bearer token"}],
        }

        model = await repo.create(payload)

        assert model.id is not None
        assert model.name == "Webhook"
        assert model.request_url == "https://example.com/webhook"
        assert model.request_method == "POST"

    @pytest.mark.asyncio
    async def test_get_by_id(self, repo):
        created = await repo.create(
            {
                "name": "Get Test",
                "on": [],
                "presets": [],
                "enabled": True,
                "request_url": "https://example.com",
                "request_method": "POST",
                "request_type": "json",
                "request_data_key": "data",
                "request_headers": [],
            }
        )

        retrieved = await repo.get(created.id)

        assert retrieved is not None
        assert retrieved.id == created.id

    @pytest.mark.asyncio
    async def test_update_notification(self, repo):
        created = await repo.create(
            {
                "name": "Update Test",
                "on": [],
                "presets": [],
                "enabled": True,
                "request_url": "https://example.com",
                "request_method": "POST",
                "request_type": "json",
                "request_data_key": "data",
                "request_headers": [],
            }
        )

        updated = await repo.update(created.id, {"name": "Updated Name", "enabled": False})

        assert updated.name == "Updated Name"
        assert updated.enabled is False

    @pytest.mark.asyncio
    async def test_delete_notification(self, repo):
        created = await repo.create(
            {
                "name": "Delete Test",
                "on": [],
                "presets": [],
                "enabled": True,
                "request_url": "https://example.com",
                "request_method": "POST",
                "request_type": "json",
                "request_data_key": "data",
                "request_headers": [],
            }
        )

        deleted = await repo.delete(created.id)

        assert deleted.id == created.id
        assert await repo.get(created.id) is None, "Deleted notification should not be retrievable"

    @pytest.mark.asyncio
    async def test_list_paginated(self, repo):
        """List paginated returns correct subset."""
        for i in range(4):
            await repo.create(
                {
                    "name": f"Item {i}",
                    "on": [],
                    "presets": [],
                    "enabled": True,
                    "request_url": "https://example.com",
                    "request_method": "POST",
                    "request_type": "json",
                    "request_data_key": "data",
                    "request_headers": [],
                }
            )

        items, total, page, total_pages = await repo.list_paginated(page=1, per_page=2)

        assert len(items) == 2
        assert total == 4
        assert page == 1
        assert total_pages == 2
