from aiohttp import web
from aiohttp.web import Response

from app.features.downloads.runtime.queue_manager import DownloadQueue
from app.library.router import route


@route("GET", "api/ping/", "ping", public=True)
async def ping(queue: DownloadQueue) -> Response:
    """
    Ping the server.

    Returns:
        Response: The response object.

    """
    await queue.queue.test()

    return web.json_response(data={"status": "pong"}, status=web.HTTPOk.status_code)
