<style scoped>
.message-collapsed {
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
}

@media (min-width: 768px) {
  .message-collapsed {
    -webkit-line-clamp: 1;
    line-clamp: 1;
  }
}
</style>

<template>
  <main class="w-full min-w-0 max-w-full space-y-6">
    <div class="ytp-page-header">
      <div class="ytp-page-heading items-start">
        <span class="ytp-page-icon">
          <UIcon
            name="i-lucide-file-text"
            :class="[
              'size-5 transition-colors',
              loading ? 'text-info' : 'animate-pulse text-success',
            ]"
            :title="loading ? t('logs.loadingHistoryTitle') : t('logs.liveStreamActiveTitle')"
            :aria-label="loading ? t('logs.loadingHistoryTitle') : t('logs.liveStreamActiveTitle')"
          />
        </span>

        <div class="min-w-0 space-y-2">
          <div class="ytp-page-kicker">
            <span>{{ pageShell.sectionLabel }}</span>
            <span>/</span>
            <span>{{ pageShell.pageLabel }}</span>
          </div>

          <p class="max-w-3xl text-sm text-toned">{{ pageShell.description }}</p>
        </div>
      </div>

      <div class="flex w-full flex-wrap items-center gap-2 xl:w-auto xl:justify-end">
        <UButton
          v-if="!autoScroll"
          color="neutral"
          variant="outline"
          size="sm"
          icon="i-lucide-arrow-down"
          @click="scrollToBottom(false)"
        >
          {{ t('common.bottom') }}
        </UButton>

        <UButton
          color="neutral"
          :variant="toggleFilter ? 'soft' : 'outline'"
          size="sm"
          icon="i-lucide-filter"
          @click="
            () => {
              toggleFilter = !toggleFilter;
            }
          "
        >
          {{ t('common.filter') }}
        </UButton>

        <UButton
          color="neutral"
          :variant="textWrap ? 'soft' : 'outline'"
          size="sm"
          icon="i-lucide-wrap-text"
          :aria-pressed="textWrap"
          :title="textWrap ? t('logs.textWrapOn') : t('logs.textWrapOff')"
          :class="['transition-all', textWrap ? '-translate-y-px ring ring-default shadow-xs' : '']"
          @click="
            () => {
              textWrap = !textWrap;
            }
          "
        >
          {{ t('common.wrap') }}
        </UButton>

        <UDropdownMenu :items="copyMenuItems" :content="copyMenuContent" :modal="false">
          <UButton
            color="neutral"
            variant="outline"
            size="sm"
            icon="i-lucide-copy"
            trailing-icon="i-lucide-chevron-down"
          >
            {{ t('common.copy') }}
          </UButton>
        </UDropdownMenu>

        <USelectMenu
          v-model="selectedLevels"
          :items="levelFilterItems"
          value-key="value"
          label-key="label"
          color="neutral"
          multiple
          size="sm"
          icon="i-lucide-list-filter"
          class="w-44 shrink-0 sm:w-48"
          :ui="{ content: 'min-w-48', item: 'ps-6' }"
          :search-input="false"
        >
          {{ levelFilterLabel }}
        </USelectMenu>

        <UButton
          color="neutral"
          variant="outline"
          size="sm"
          icon="i-lucide-sliders-horizontal"
          class="shrink-0"
          :loading="runtimeLogLevelLoading"
          :disabled="!canApplyRuntimeLogLevel || runtimeLogLevelLoading"
          @click="applyRuntimeLogLevel"
        >
          {{ t('common.apply') }}
        </UButton>

        <UInput
          v-if="toggleFilter || query"
          id="filter"
          v-model.lazy="query"
          type="search"
          :placeholder="t('common.filterDisplayedContent')"
          icon="i-lucide-filter"
          size="sm"
          class="order-last w-full sm:order-first sm:w-80"
        />
      </div>
    </div>

    <div class="ytp-frame overflow-hidden rounded-none bg-elevated/20 shadow-sm">
      <div
        ref="logContainer"
        class="w-full min-w-0 max-w-full min-h-[55vh] max-h-[60vh] overflow-y-auto overflow-x-hidden bg-transparent font-mono text-sm text-default overscroll-x-contain"
        dir="ltr"
        @scroll.passive="handleScroll"
      >
        <div
          v-if="reachedEnd && !hasActiveFilter"
          class="flex justify-center border-b border-default/40 px-4 py-3"
        >
          <div
            class="inline-flex items-center gap-1.5 rounded-full border border-warning/30 bg-warning/10 px-3 py-1 text-[11px] font-medium text-warning"
          >
            <UIcon name="i-lucide-triangle-alert" class="size-3.5 shrink-0" />
            {{ t('logs.emptyOlder') }}
          </div>
        </div>

        <div
          v-if="canLoadFilteredHistory"
          class="flex justify-center border-b border-default/40 px-4 py-3"
        >
          <button
            type="button"
            class="inline-flex items-center gap-1.5 rounded-full border border-default/60 bg-elevated/40 px-3 py-1 text-[11px] font-medium text-toned transition-colors hover:border-default hover:text-default disabled:opacity-60"
            :disabled="loading"
            @click="fetchLogs(true)"
          >
            <UIcon
              :name="loading ? 'i-lucide-loader-circle' : 'i-lucide-history'"
              :class="['size-3.5 shrink-0', loading ? 'animate-spin' : '']"
            />
            {{ t('logs.loadOlder') }}
          </button>
        </div>

        <template v-if="filteredLogs.length > 0">
          <article
            v-for="(entry, index) in filteredLogs"
            :key="entry.log.id"
            :class="logRowClass(entry, index)"
          >
            <div
              class="flex w-full min-w-0 flex-col gap-1 px-3 py-[0.65rem] leading-[1.6] md:flex-row md:items-start md:gap-2"
            >
              <span
                class="inline-flex max-w-full flex-wrap items-center gap-x-2 gap-y-1 align-middle md:shrink-0 md:flex-nowrap"
              >
                <UTooltip :text="logTimeTitle(entry.log.datetime)">
                  <span class="inline text-[11px] font-semibold text-toned cursor-pointer">
                    {{ logTimeLabel(entry.log.datetime) }}
                  </span>
                </UTooltip>
                <UDropdownMenu
                  :items="logMenuItems(entry.log)"
                  :content="{ align: 'start' }"
                  :modal="false"
                >
                  <UButton
                    color="neutral"
                    variant="ghost"
                    size="xs"
                    icon="i-lucide-ellipsis-vertical"
                    trailing-icon="i-lucide-chevron-down"
                    class="inline-flex h-5! align-[-0.2em] opacity-70 hover:opacity-100"
                    :ui="{
                      base: 'min-h-0 min-w-0',
                      leadingIcon: 'size-3',
                      trailingIcon: 'size-3',
                    }"
                  >
                    <span class="text-[10px] font-medium">{{ t('common.actions') }}</span>
                  </UButton>
                </UDropdownMenu>
                <span
                  :class="logLevelBadgeClass(getLogLevel(entry.log.level))"
                  @click="openLogDetails(entry.log)"
                >
                  <UIcon :name="LOG_LEVEL_ICON[getLogLevel(entry.log.level)]" class="size-3" />
                  {{ getLogLevel(entry.log.level) }}
                </span>
                <span
                  v-if="entry.log.logger && !['ytptube', 'http_api'].includes(entry.log.logger)"
                  :title="entry.log.logger"
                  class="inline-block max-w-[46vw] truncate align-middle text-[11px] font-semibold text-toned sm:max-w-104"
                  >[{{ entry.log.logger }}]</span
                >
              </span>

              <button
                type="button"
                class="block min-w-0 flex-1 cursor-pointer text-start"
                :aria-expanded="expandedRows.has(entry.log.id) || textWrap"
                @click="toggleRow(entry.log.id)"
              >
                <span :class="messageClass(entry.log.id)"
                  >{{ entry.log.message
                  }}<span v-if="exceptionSummary(entry.log)" class="text-error/90">
                    : {{ exceptionSummary(entry.log) }}</span
                  ></span
                >
              </button>
            </div>
          </article>
        </template>

        <div
          v-else
          class="flex min-h-[55vh] flex-col items-center justify-center gap-3 px-6 py-8 text-center font-sans"
        >
          <template v-if="loading">
            <UIcon name="i-lucide-loader-circle" class="size-6 animate-spin text-toned" />
            <div class="space-y-1">
              <p class="text-sm font-medium text-default">{{ t('logs.loadingLogs') }}</p>
              <p class="text-sm text-toned">{{ t('logs.connectingStream') }}</p>
            </div>
          </template>

          <template v-else-if="hasActiveFilter">
            <UIcon name="i-lucide-filter-x" class="size-6 text-toned" />
            <div class="space-y-1">
              <p class="text-sm font-medium text-default">{{ t('logs.emptyFilter') }}</p>
              <p class="text-sm text-toned">{{ t('logs.emptyFilterDesc') }}</p>
            </div>
          </template>

          <template v-else>
            <UIcon name="i-lucide-circle-off" class="size-6 text-toned" />
            <div class="space-y-1">
              <p class="text-sm font-medium text-default">{{ t('logs.emptyLines') }}</p>
              <p class="text-sm text-toned">{{ t('logs.emptyLinesDesc') }}</p>
            </div>
          </template>
        </div>
      </div>
    </div>

    <LazyLogDetailModal v-if="detailsOpen" v-model="detailsOpen" :log="selectedLog" />
  </main>
</template>

<script setup lang="ts">
import { fetchEventSource } from '@microsoft/fetch-event-source';
import type { EventSourceMessage } from '@microsoft/fetch-event-source';
import { useStorage } from '@vueuse/core';
import type { log_line } from '~/types/logs';
import { copyText, parse_api_error, request, uri } from '~/utils';
import { usePageShell } from '~/composables/usePageShell';
import { formatClock, formatDateTime } from '~/utils/date';
const { locale, t } = useI18n();

type FilteredLogEntry = {
  log: log_line;
  level: LogLevel;
  isMatch: boolean;
  isContext: boolean;
};

type LogLevel = 'debug' | 'info' | 'warning' | 'error';
type LevelFilterItem = {
  label: string;
  value: LogLevel;
};

const FILTER_CONTEXT_REGEX = /context:(\d+)/;
const LOG_LEVELS: LogLevel[] = ['debug', 'info', 'warning', 'error'];
const LOG_ROW_CLASS =
  'flex min-w-0 border-b border-default/40 bg-transparent transition-colors duration-150 last:border-b-0 hover:bg-elevated/70';
const LOG_LEVEL_ICON: Record<LogLevel, string> = {
  debug: 'i-lucide-terminal',
  info: 'i-lucide-info',
  warning: 'i-lucide-triangle-alert',
  error: 'i-lucide-circle-x',
};
const formatLogLevel = (level: LogLevel): string => level.charAt(0).toUpperCase() + level.slice(1);
const getStoredRuntimeLogLevel = (): LogLevel | null => {
  return config.app.runtime_log_level ? getLogLevel(config.app.runtime_log_level) : null;
};

let scrollTimeout: NodeJS.Timeout | null = null;

const toast = useNotification();
const config = useYtpConfig();
const route = useRoute();
const pageShell = usePageShell('logs');

const logContainer = useTemplateRef<HTMLDivElement>('logContainer');
const textWrap = useStorage<boolean>('logs_text_wrap', false);
const selectedLevels = useStorage<LogLevel[]>('logs_level_filter', [...LOG_LEVELS]);
const sseController = ref<AbortController | null>(null);
const runtimeLogLevel = ref<LogLevel | null>(null);
const runtimeLogLevelLoading = ref(false);

const logs = ref<Array<log_line>>([]);
const selectedLog = ref<log_line | null>(null);
const offset = ref(0);
const loading = ref(false);
const autoScroll = ref(true);
const reachedEnd = ref(false);
const detailsOpen = ref(false);
const expandedRows = ref<Set<string>>(new Set());

const query = ref<string>(
  (() => {
    const filter = route.query.filter ?? '';
    if (!filter) {
      return '';
    }

    if (typeof filter === 'string') {
      return filter.trim();
    }

    if (Array.isArray(filter) && filter.length > 0) {
      return filter[0]?.trim() ?? '';
    }

    return '';
  })(),
);

const toggleFilter = ref(Boolean(query.value));

const normalizedQuery = computed(() => query.value.trim().toLowerCase());
const selectedLevelSet = computed(
  () => new Set(LOG_LEVELS.filter((level) => selectedLevels.value.includes(level))),
);
const filterContext = computed(() => {
  const match = normalizedQuery.value.match(FILTER_CONTEXT_REGEX);
  return match ? parseInt(match[1] ?? '0', 10) : 0;
});
const searchTerm = computed(() => normalizedQuery.value.replace(FILTER_CONTEXT_REGEX, '').trim());
const hasTextFilter = computed(() => Boolean(searchTerm.value));
const hasActiveFilter = computed(() => hasTextFilter.value);
const canLoadFilteredHistory = computed(
  () => hasTextFilter.value && !reachedEnd.value && logs.value.length > 0,
);
const copyMenuContent = computed(() => ({ align: 'end' as const }));
const copyMenuItems = computed(() => [
  [
    {
      label: t('logs.copyRendered'),
      icon: 'i-lucide-file-text',
      onSelect: () => copyText(copyRenderedLogText.value),
    },
    {
      label: t('logs.copyRaw'),
      icon: 'i-lucide-file-code',
      onSelect: () => copyText(copyRawLogText.value),
    },
  ],
]);
const logMenuItems = (log: log_line) => [
  [
    {
      label: t('common.details'),
      icon: 'i-lucide-panel-right-open',
      onSelect: () => openLogDetails(log),
    },
    {
      label: t('logs.copyRendered'),
      icon: 'i-lucide-file-text',
      onSelect: () => copyText(formatLogLine(log)),
    },
    {
      label: t('logs.copyRaw'),
      icon: 'i-lucide-file-code',
      onSelect: () => copyText(JSON.stringify(log)),
    },
  ],
];
const levelCounts = computed<Record<LogLevel, number>>(() => {
  const counts: Record<LogLevel, number> = {
    debug: 0,
    info: 0,
    warning: 0,
    error: 0,
  };

  logs.value.forEach((log) => {
    const level = getLogLevel(log.level);
    counts[level] += 1;
  });

  return counts;
});

const levelFilterItems = computed<LevelFilterItem[]>(() => [
  ...LOG_LEVELS.map((level) => ({
    label: `${formatLogLevel(level)} (${levelCounts.value[level]})`,
    value: level,
  })),
]);

const runtimeLogLevelCandidate = computed<LogLevel | null>(() => {
  for (const level of LOG_LEVELS) {
    const thresholdLevels = LOG_LEVELS.slice(LOG_LEVELS.indexOf(level));
    if (thresholdLevels.length !== selectedLevelSet.value.size) {
      continue;
    }

    if (thresholdLevels.every((item) => selectedLevelSet.value.has(item))) {
      return level;
    }
  }

  return null;
});

const canApplyRuntimeLogLevel = computed(
  () =>
    runtimeLogLevelCandidate.value !== null &&
    runtimeLogLevel.value !== null &&
    runtimeLogLevelCandidate.value !== runtimeLogLevel.value,
);

const levelFilterLabel = computed(() => {
  if (selectedLevelSet.value.size === LOG_LEVELS.length) {
    return t('logs.allLevels');
  }

  if (selectedLevelSet.value.size === 0) {
    return t('logs.noLevelsSelected');
  }

  return LOG_LEVELS.filter((level) => selectedLevelSet.value.has(level)).join(', ');
});

watch(toggleFilter, () => {
  if (!toggleFilter.value) {
    query.value = '';
    scrollToBottom(true);
  }
});

watch(
  () => config.app.file_logging,
  async (value) => {
    if (value) {
      return;
    }

    await navigateTo('/');
  },
);

watch(detailsOpen, (open) => {
  if (!open) {
    selectedLog.value = null;
  }
});

const filteredLogs = computed<FilteredLogEntry[]>(() => {
  if (!hasActiveFilter.value) {
    return logs.value
      .filter((log) => selectedLevelSet.value.has(getLogLevel(log.level)))
      .map((log) => ({
        log,
        level: getLogLevel(log.level),
        isMatch: false,
        isContext: false,
      }));
  }

  const result: Array<FilteredLogEntry> = [];
  const visibleIndexes = new Set<number>();
  const matchedIndexes = new Set<number>();

  logs.value.forEach((log, index) => {
    if (!selectedLevelSet.value.has(getLogLevel(log.level))) {
      return;
    }

    if (!hasTextFilter.value) {
      visibleIndexes.add(index);
      return;
    }

    if (searchableLog(log).includes(searchTerm.value)) {
      matchedIndexes.add(index);

      for (
        let i = Math.max(0, index - filterContext.value);
        i <= Math.min(logs.value.length - 1, index + filterContext.value);
        i++
      ) {
        visibleIndexes.add(i);
      }
    }
  });

  Array.from(visibleIndexes)
    .sort((a, b) => a - b)
    .forEach((index) => {
      const log = logs.value[index] as log_line;
      if (!selectedLevelSet.value.has(getLogLevel(log.level))) {
        return;
      }

      result.push({
        log,
        level: getLogLevel(log.level),
        isMatch: matchedIndexes.has(index),
        isContext: !matchedIndexes.has(index),
      });
    });

  return result;
});

const scrollLogContainerToBottom = async (behavior: ScrollBehavior = 'auto'): Promise<void> => {
  await nextTick();

  if (!logContainer.value) {
    return;
  }

  logContainer.value.scrollTo({
    top: logContainer.value.scrollHeight,
    behavior,
  });
};

const fetchLogs = async (force = false): Promise<void> => {
  loading.value = true;

  if (reachedEnd.value || (!force && hasTextFilter.value && logs.value.length > 0)) {
    loading.value = false;
    return;
  }

  try {
    const req = await request(`/api/logs?offset=${offset.value}`);
    if (!req.ok) {
      toast.error(t('common.failedFetch'));
      return;
    }

    const response = await req.json();
    if (response.error) {
      toast.error(await parse_api_error(response));
      return;
    }

    const lines = response.logs ?? [];
    if (lines.length) {
      logs.value.unshift(...response.logs);
    }

    if (response?.next_offset) {
      offset.value = response.next_offset;
    }

    if (response?.end_is_reached) {
      reachedEnd.value = true;
    }

    if (autoScroll.value) {
      await scrollLogContainerToBottom();
    }
  } catch (error) {
    console.error('Failed to fetch logs:', error);
  } finally {
    loading.value = false;
  }
};

const handleScroll = (): void => {
  if (!logContainer.value || hasTextFilter.value) {
    return;
  }

  const container = logContainer.value;
  const nearBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - 50;
  const nearTop = container.scrollTop < 50;

  autoScroll.value = nearBottom;

  if (nearTop && !loading.value && !scrollTimeout && !reachedEnd.value) {
    scrollTimeout = setTimeout(async () => {
      const previousHeight = container.scrollHeight;
      await fetchLogs();
      await nextTick(() => {
        const newHeight = container.scrollHeight;
        container.scrollTop += newHeight - previousHeight;
      });
      scrollTimeout = null;
    }, 300);
  }
};

const scrollToBottom = async (fast = false): Promise<void> => {
  autoScroll.value = true;
  await scrollLogContainerToBottom(fast ? 'auto' : 'smooth');
};

const loadRuntimeLogLevel = async (): Promise<void> => {
  try {
    const response = await request('/api/logs/level');
    if (!response.ok) {
      runtimeLogLevel.value = getStoredRuntimeLogLevel();
      return;
    }

    const data = await response.json();
    if (typeof data.conf === 'string' && data.conf) {
      config.app.log_level = getLogLevel(data.conf);
    }

    if (!config.app.log_level && getStoredRuntimeLogLevel() === null) {
      runtimeLogLevel.value = null;
      return;
    }

    if (typeof data.active === 'string' && data.active) {
      const level = getLogLevel(data.active);
      runtimeLogLevel.value = level;
      config.app.runtime_log_level = level;
      return;
    }

    runtimeLogLevel.value = getStoredRuntimeLogLevel();
  } catch (error) {
    runtimeLogLevel.value = getStoredRuntimeLogLevel();
    console.error('Failed to load runtime log level:', error);
  }
};

const applyRuntimeLogLevel = async (): Promise<void> => {
  const normalized = runtimeLogLevelCandidate.value;
  if (!normalized || runtimeLogLevel.value === null || normalized === runtimeLogLevel.value) {
    return;
  }

  const previous = runtimeLogLevel.value;

  try {
    runtimeLogLevelLoading.value = true;
    const response = await request(`/api/logs/level/${normalized}`, {
      method: 'POST',
    });

    if (!response.ok) {
      const data = await response.json();
      const message = await parse_api_error(data);
      runtimeLogLevel.value = previous;
      toast.error(t('logs.failedLogLevel', { msg: message }));
      return;
    }

    runtimeLogLevel.value = normalized;
    config.app.runtime_log_level = normalized;
    toast.success(t('common.logLevelUpdated'));
  } catch (error: any) {
    runtimeLogLevel.value = previous;
    const message = error?.message || t('common.unknownError');
    toast.error(t('logs.failedLogLevel', { msg: message }));
  } finally {
    runtimeLogLevelLoading.value = false;
  }
};

const handleStreamMessage = (event: EventSourceMessage): void => {
  if (event.event !== 'log_lines' || !event.data) {
    return;
  }

  let payload: log_line | null = null;
  try {
    payload = JSON.parse(event.data) as log_line;
  } catch {
    payload = null;
  }

  if (!payload) {
    return;
  }

  logs.value.push(payload);

  if (autoScroll.value) {
    void scrollLogContainerToBottom('smooth');
  }
};

const startLogStream = async (): Promise<void> => {
  sseController.value?.abort();
  const controller = new AbortController();
  sseController.value = controller;

  try {
    await fetchEventSource(uri('/api/logs/stream'), {
      method: 'GET',
      headers: {
        Accept: 'text/event-stream',
      },
      credentials: 'same-origin',
      signal: controller.signal,
      onopen: async (response) => {
        if (response.ok) {
          return;
        }

        let message = response.statusText || t('logs.failedStream');
        try {
          message = await parse_api_error(response.clone().json());
        } catch {
          try {
            const text = await response.text();
            if (text) {
              message = text;
            }
          } catch {
            message = response.statusText || t('logs.failedStream');
          }
        }

        throw new Error(message);
      },
      onmessage: handleStreamMessage,
      onerror: (error) => {
        if (controller.signal.aborted) {
          return;
        }

        console.error('Log stream error:', error);
      },
    });
  } catch (error) {
    if (!controller.signal.aborted) {
      console.error('Log stream error:', error);
    }
  } finally {
    if (controller === sseController.value) {
      sseController.value = null;
    }
  }
};

const logTimeLabel = (value?: string): string =>
  value ? formatClock(value, locale.value) : '00:00:00';

const logTimeTitle = (value?: string): string =>
  value ? formatDateTime(value, locale.value, { seconds: true }) : t('logs.noTimestamp');

const exceptionSummary = (log: log_line): string => {
  const type = log.exception?.type?.trim() ?? '';
  const message = log.exception?.message?.trim() ?? '';

  if (type && message) {
    return `${type}: ${message}`;
  }

  return type || message;
};

const formatLogLine = (log: log_line): string =>
  [
    log.datetime,
    getLogLevel(log.level).toUpperCase(),
    log.logger ? `[${log.logger}]` : '',
    exceptionSummary(log) ? `${log.message}: ${exceptionSummary(log)}` : log.message,
  ]
    .filter(Boolean)
    .join(' ');

const rawLogText = computed(() => logs.value.map((log) => JSON.stringify(log)).join('\n'));
const renderedLogText = computed(() => logs.value.map((log) => formatLogLine(log)).join('\n'));
const filteredRawLogText = computed(() =>
  filteredLogs.value.map((entry) => JSON.stringify(entry.log)).join('\n'),
);
const filteredRenderedLogText = computed(() =>
  filteredLogs.value.map((entry) => formatLogLine(entry.log)).join('\n'),
);
const copyRawLogText = computed(() =>
  hasActiveFilter.value ? filteredRawLogText.value : rawLogText.value,
);
const copyRenderedLogText = computed(() =>
  hasActiveFilter.value ? filteredRenderedLogText.value : renderedLogText.value,
);

const searchableLog = (log: log_line): string =>
  [
    log.message,
    log.level,
    log.logger,
    exceptionSummary(log),
    log.exception ? JSON.stringify(log.exception) : '',
    log.source ? JSON.stringify(log.source) : '',
    log.process ? JSON.stringify(log.process) : '',
    log.thread ? JSON.stringify(log.thread) : '',
    log.fields ? JSON.stringify(log.fields) : '',
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();

const getLogLevel = (level: string): LogLevel => {
  switch (level.toLowerCase()) {
    case 'info':
      return 'info';
    case 'warning':
    case 'warn':
      return 'warning';
    case 'error':
    case 'critical':
    case 'fatal':
      return 'error';
    default:
      return 'debug';
  }
};

const logLevelBadgeClass = (level: LogLevel): string[] => [
  'inline-flex items-center gap-1.5 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide cursor-pointer',
  level === 'debug' ? 'bg-muted/40 text-muted' : '',
  level === 'info' ? 'bg-info/10 text-info' : '',
  level === 'warning' ? 'bg-warning/10 text-warning' : '',
  level === 'error' ? 'bg-error/10 text-error' : '',
];

const messageClass = (id: string): string[] => [
  'block text-sm text-default',
  expandedRows.value.has(id) || textWrap.value
    ? 'whitespace-pre-wrap wrap-break-word'
    : 'message-collapsed md:block md:truncate',
];

const toggleRow = (id: string): void => {
  const next = new Set(expandedRows.value);
  if (next.has(id)) {
    next.delete(id);
  } else {
    next.add(id);
  }
  expandedRows.value = next;
};

const logRowClass = (entry: FilteredLogEntry, index: number): string[] => {
  const classes = [LOG_ROW_CLASS];

  if (entry.isMatch) {
    classes.push('bg-warning/10');
    return classes;
  }

  if (entry.isContext) {
    classes.push('bg-muted/30');
    return classes;
  }

  if (index % 2 === 1) {
    classes.push('bg-elevated/40');
  }

  return classes;
};

const openLogDetails = (log: log_line): void => {
  selectedLog.value = log;
  detailsOpen.value = true;
};

onMounted(async () => {
  if (!config.app.file_logging) {
    await navigateTo('/');
    return;
  }

  runtimeLogLevel.value = getStoredRuntimeLogLevel();
  await loadRuntimeLogLevel();
  await fetchLogs();
  await startLogStream();
});

onBeforeUnmount(() => {
  sseController.value?.abort();

  if (scrollTimeout) {
    clearTimeout(scrollTimeout);
    scrollTimeout = null;
  }
});
</script>
