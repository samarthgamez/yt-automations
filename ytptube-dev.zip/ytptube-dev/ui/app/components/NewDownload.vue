<template>
  <main class="space-y-4">
    <FormSubmitError :message="submitError" @dismiss="submitError = ''" />
    <form autocomplete="off" class="space-y-4" @submit.prevent="addDownload">
      <div class="ytp-card p-4 sm:p-6 space-y-4">
        <div class="space-y-4">
          <UFormField class="w-full" :ui="downloadFieldUi">
            <template #label>
              <div class="flex flex-wrap items-center gap-2">
                <UTooltip :text="t('common.downloadUrlHint')">
                  <UIcon name="i-lucide-link" class="size-4 text-toned" />
                </UTooltip>
                <span class="font-semibold text-default">{{ t('common.url') }}</span>
              </div>
            </template>
            <template #description>
              <span>{{
                t('common.urlsSeparatedBy', { separator: getSeparatorsName(separator) })
              }}</span>
            </template>
            <UFieldGroup v-if="!isMultiLineInput" size="lg" class="w-full">
              <UInput
                id="url"
                v-model="form.url"
                dir="ltr"
                type="text"
                :placeholder="t('common.urlsPlaceholder')"
                :disabled="addInProgress"
                :variant="show_description ? 'soft' : 'outline'"
                color="neutral"
                class="min-w-0 flex-1"
                :ui="{
                  root: 'w-full',
                  base: 'bg-elevated/60 ring-default focus-visible:ring-primary',
                }"
                @keydown="handleKeyDown"
                @paste="handlePaste"
                @update:model-value="clearPickedEntries"
                autofocus
              />

              <UButton
                type="submit"
                color="primary"
                icon="i-lucide-download"
                :loading="addInProgress"
                :disabled="addInProgress || !hasValidUrl"
                class="justify-center sm:min-w-28"
              >
                {{ t('common.download') }}
              </UButton>
              <UDropdownMenu :items="downloadActionGroups" :modal="false">
                <UButton
                  color="primary"
                  icon="i-lucide-chevron-down"
                  :aria-label="t('common.actions')"
                  :loading="scheduleInProgress"
                  :disabled="addInProgress || scheduleInProgress || !hasValidUrl"
                  square
                />
              </UDropdownMenu>
            </UFieldGroup>

            <div v-else class="flex flex-row gap-2 items-start">
              <div class="min-w-0 flex-1">
                <UTextarea
                  ref="urlTextarea"
                  id="url"
                  v-model="form.url"
                  dir="ltr"
                  :disabled="addInProgress"
                  size="lg"
                  :variant="show_description ? 'soft' : 'outline'"
                  color="neutral"
                  class="w-full"
                  :rows="3"
                  :maxrows="12"
                  autoresize
                  :ui="{
                    root: 'w-full',
                    base: 'min-h-[7.25rem] bg-elevated/60 ring-default focus-visible:ring-primary',
                  }"
                  @keydown="handleKeyDown"
                  @update:model-value="clearPickedEntries"
                  autofocus
                />
              </div>

              <UFieldGroup size="lg">
                <UButton
                  type="submit"
                  color="primary"
                  icon="i-lucide-download"
                  :loading="addInProgress"
                  :disabled="addInProgress || !hasValidUrl"
                  class="justify-center sm:min-w-28"
                >
                  {{ t('common.download') }}
                </UButton>
                <UDropdownMenu :items="downloadActionGroups" :modal="false">
                  <UButton
                    color="primary"
                    icon="i-lucide-chevron-down"
                    :aria-label="t('common.actions')"
                    :loading="scheduleInProgress"
                    :disabled="addInProgress || scheduleInProgress || !hasValidUrl"
                    square
                  />
                </UDropdownMenu>
              </UFieldGroup>
            </div>
          </UFormField>

          <div
            class="grid gap-4 xl:grid-cols-[minmax(0,0.95fr)_minmax(0,1.95fr)_11rem] xl:items-end"
          >
            <UFormField
              class="min-w-0 w-full"
              :label="t('common.presetLabel')"
              :ui="downloadFieldUi"
              :description="hasFormatInConfig ? t('common.presetDisabled') : t('common.presetDesc')"
            >
              <template #label>
                <span class="inline-flex items-center gap-2 font-semibold">
                  <UIcon name="i-lucide-sliders-horizontal" class="size-4 text-toned" />
                  <span>{{ t('common.presetLabel') }}</span>
                </span>
              </template>

              <div class="flex w-full gap-2">
                <UButton
                  color="neutral"
                  :variant="show_description ? 'soft' : 'outline'"
                  icon="i-lucide-info"
                  square
                  class="shrink-0"
                  @click="
                    () => {
                      show_description = !show_description;
                    }
                  "
                />

                <div class="min-w-0 flex-1">
                  <USelectMenu
                    id="preset"
                    v-model="form.preset"
                    :items="presetItems"
                    value-key="value"
                    label-key="label"
                    color="neutral"
                    class="w-full"
                    size="lg"
                    :ui="{ content: 'min-w-[13rem]', item: 'ps-6' }"
                    :search-input="{ placeholder: t('common.searchPresets') }"
                    :disabled="addInProgress || hasFormatInConfig"
                    :placeholder="t('common.selectPreset')"
                  />
                </div>
              </div>
            </UFormField>

            <UFormField
              class="min-w-0 w-full"
              :label="t('common.downloadPath')"
              :ui="downloadFieldUi"
              :description="t('common.downloadPathHint', { path: config.app.download_path })"
            >
              <template #label>
                <span class="inline-flex items-center gap-2 font-semibold">
                  <UIcon name="i-lucide-folder-output" class="size-4 text-toned" />
                  <span>{{ t('common.downloadPath') }}</span>
                </span>
              </template>

              <div class="flex items-center gap-2" dir="ltr">
                <span
                  class="max-w-44 shrink-0 truncate rounded-md border border-default bg-muted/40 px-3 py-2 text-xs text-toned"
                  :title="config.app.download_path"
                >
                  {{ shortPath(config.app.download_path) }}
                </span>

                <FolderInput
                  id="folder"
                  v-model="form.folder"
                  :placeholder="getDefault('folder', '/')"
                  :disabled="addInProgress"
                  :ui="{ root: 'w-full', base: 'bg-default/90' }"
                />
              </div>
            </UFormField>

            <div class="flex w-full items-end xl:col-span-1">
              <UButton
                type="button"
                color="neutral"
                :variant="showAdvanced ? 'soft' : 'outline'"
                icon="i-lucide-settings-2"
                size="lg"
                class="w-full justify-center"
                @click="
                  () => {
                    showAdvanced = !showAdvanced;
                  }
                "
              >
                {{ showAdvanced ? t('common.hideOptions') : t('common.showOptions') }}
              </UButton>
            </div>
          </div>
        </div>

        <div
          v-if="show_description && !hasFormatInConfig && findPreset(form.preset)?.description"
          class="max-h-36 overflow-auto rounded-md border border-default bg-muted/30 px-3 py-2 text-sm text-toned"
        >
          <button
            type="button"
            class="block w-full cursor-pointer text-start"
            @click="expand_description"
          >
            <span class="inline-flex items-start gap-2">
              <UIcon name="i-lucide-info" class="mt-0.5 size-4 shrink-0 text-info" />
              <span class="is-ellipsis">{{ findPreset(form.preset)?.description }}</span>
            </span>
          </button>
        </div>
      </div>

      <div v-if="showAdvanced" class="ytp-card p-4 sm:p-6 space-y-4">
        <div class="space-y-4">
          <div class="grid gap-3 md:grid-cols-2 xl:grid-cols-12">
            <div class="xl:col-span-2">
              <DLInput
                id="force_download"
                v-model="dlFields['--no-download-archive']"
                type="bool"
                :label="t('common.forceDownload')"
                icon="i-lucide-download"
                :disabled="addInProgress"
                compact
              />
            </div>

            <div class="xl:col-span-2">
              <DLInput
                id="auto_start"
                v-model="auto_start"
                type="bool"
                :label="t('common.autoStart')"
                icon="i-lucide-play"
                :disabled="addInProgress"
                compact
              />
            </div>

            <div class="xl:col-span-2">
              <DLInput
                id="no_cache"
                v-model="dlFields['--no-continue']"
                type="bool"
                :label="t('common.bypassCache')"
                icon="i-lucide-eraser"
                :disabled="addInProgress"
                compact
              />
            </div>

            <div
              :class="
                hasIgnoreConditionOptions
                  ? 'md:col-span-2 xl:col-span-3'
                  : 'md:col-span-2 xl:col-span-6'
              "
            >
              <DLInput
                id="output_template"
                v-model="form.template"
                type="string"
                :label="t('common.outputTemplate')"
                icon="i-lucide-file-code-2"
                :disabled="addInProgress"
                :placeholder="
                  getDefault('template', config.app.output_template || '%(title)s.%(ext)s')
                "
              >
                <template #description>
                  <span>
                    {{ t('common.outputTemplateDescPrefix')
                    }}<NuxtLink
                      target="_blank"
                      class="font-medium text-primary hover:underline"
                      to="https://github.com/yt-dlp/yt-dlp#output-template"
                    >
                      {{ t('common.outputTemplateDescLink') }}</NuxtLink
                    >{{ t('common.outputTemplateDescSuffix') }}
                  </span>
                </template>
              </DLInput>
            </div>

            <UFormField
              v-if="hasIgnoreConditionOptions"
              class="md:col-span-2 xl:col-span-3 w-full"
              :ui="advancedEditorFieldUi"
            >
              <template #label>
                <span class="inline-flex items-center gap-2 font-semibold">
                  <UIcon name="i-lucide-list-minus" class="size-4 text-toned" />
                  <span>{{ t('common.ignoreConditions') }}</span>
                </span>
              </template>

              <template #description>
                <span>{{ t('common.ignoreConditionsDesc') }}</span>
              </template>

              <template #hint>
                <button
                  v-if="selectedIgnoreConditions.length > 0"
                  type="button"
                  class="font-medium text-primary hover:underline"
                  @click="selectedIgnoreConditions = []"
                >
                  {{ t('common.clearSelection') }}
                </button>
              </template>

              <USelectMenu
                v-model="selectedIgnoreConditions"
                :items="ignoreConditionOptions"
                value-key="value"
                label-key="label"
                multiple
                :placeholder="t('common.selectConditions')"
                class="w-full"
                size="lg"
                :disabled="addInProgress || conditions.isLoading.value"
                :search-input="{ placeholder: t('common.searchConditions') }"
                :ui="{ base: 'w-full', content: 'min-w-[18rem]' }"
              />
            </UFormField>
          </div>

          <div class="grid gap-4 xl:grid-cols-2">
            <UFormField :label="t('common.cliOptions')" class="w-full" :ui="advancedEditorFieldUi">
              <template #label>
                <span class="inline-flex items-center gap-2 font-semibold">
                  <UIcon name="i-lucide-terminal" class="size-4 text-toned" />
                  <span>{{ t('common.cliOptions') }}</span>
                </span>
              </template>

              <template #description>
                <span>
                  <button
                    type="button"
                    class="font-medium text-primary hover:underline"
                    @click="showOptions = true"
                  >
                    {{ t('common.cliOptionsViewAll') }}
                  </button>
                  {{ t('common.cliOptionsDescPrefix')
                  }}<a
                    target="_blank"
                    href="https://github.com/arabcoders/ytptube/blob/master/app/features/ytdlp/utils.py#L29"
                  >
                    {{ t('common.cliOptionsDescIgnored') }}
                  </a>
                </span>
              </template>

              <TextareaAutocomplete
                id="cli_options"
                v-model="form.cli"
                :options="ytDlpOpt"
                :placeholder="getDefault('cli', '')"
                :disabled="addInProgress"
                :rows="5"
                class="w-full"
              />
            </UFormField>

            <UFormField
              :label="t('common.cookiesLabel')"
              class="w-full"
              :ui="advancedEditorFieldUi"
            >
              <template #label>
                <span class="inline-flex items-center gap-2 font-semibold">
                  <UIcon name="i-lucide-cookie" class="size-4 text-toned" />
                  <span>{{ t('common.cookiesLabel') }}</span>
                </span>
              </template>

              <template #hint>
                <button
                  type="button"
                  class="font-medium text-primary hover:underline"
                  @click="cookiesDropzoneRef?.triggerFileSelect()"
                >
                  {{ t('common.uploadFile') }}
                </button>
              </template>
              <template #description>
                <span>
                  {{ t('common.cookiesInstructionsPrefix')
                  }}<NuxtLink
                    target="_blank"
                    to="https://github.com/yt-dlp/yt-dlp/wiki/FAQ#how-do-i-pass-cookies-to-yt-dlp"
                  >
                    {{ t('common.recommendedAddon') }}</NuxtLink
                  >{{ t('common.cookiesInstructionsSuffix')
                  }}<span class="text-error">{{ t('common.cookiesInstructionsFormat') }}</span>
                </span>
              </template>

              <TextDropzone
                ref="cookiesDropzoneRef"
                id="ytdlpCookies"
                v-model="form.cookies"
                :disabled="addInProgress"
                :rows="5"
                :placeholder="getDefault('cookies', t('common.cookiesPlaceholder'))"
                class="w-full"
                @error="(message: string) => (submitError = message)"
              />
            </UFormField>
          </div>

          <div v-if="config.dl_fields.length > 0" class="grid gap-4 md:grid-cols-2 xl:grid-cols-2">
            <DLInput
              v-for="(fi, index) in sortedDLFields"
              :id="fi?.id || `dlf-${index}`"
              :key="fi.id || `dlf-${index}`"
              v-model="dlFields[fi.field]"
              :type="fi.kind"
              :description="fi.description"
              :label="fi.name"
              :icon="fi.icon"
              :field="fi.field"
              :disabled="addInProgress"
            />
          </div>
        </div>

        <div class="flex flex-wrap items-center justify-between gap-2 border-t border-default pt-4">
          <UDropdownMenu class="w-full sm:hidden" :items="mobileActionGroups" :modal="false">
            <UButton
              color="neutral"
              variant="outline"
              icon="i-lucide-ellipsis"
              trailing-icon="i-lucide-chevron-down"
              class="w-full justify-center"
            >
              {{ t('common.actions') }}
            </UButton>
          </UDropdownMenu>

          <div class="hidden flex-wrap items-center gap-2 sm:flex">
            <UButton
              type="button"
              color="neutral"
              variant="outline"
              icon="i-lucide-info"
              :disabled="addInProgress || !hasSingleUrl"
              @click="emitter('getInfo', splitUrls(form.url || '')[0] || '', form.preset, form.cli)"
            >
              {{ t('common.ytdlpInformation') }}
            </UButton>

            <UButton
              v-if="config.app.console_enabled"
              type="button"
              color="neutral"
              variant="outline"
              icon="i-lucide-terminal"
              :disabled="!hasValidUrl"
              @click="runCliCommand"
            >
              {{ t('common.runCli') }}
            </UButton>

            <UButton
              v-if="config.app.console_enabled"
              type="button"
              color="neutral"
              variant="outline"
              icon="i-lucide-flask-conical"
              :disabled="!hasValidUrl"
              @click="testDownloadOptions"
            >
              {{ t('common.showCompiledOptions') }}
            </UButton>
          </div>

          <UButton
            type="button"
            color="neutral"
            variant="outline"
            icon="i-lucide-rotate-ccw"
            :disabled="!!form?.id"
            class="hidden sm:inline-flex"
            @click="resetConfig"
          >
            {{ t('common.resetLocalSettings') }}
          </UButton>
        </div>
      </div>
    </form>

    <UModal
      v-if="showOptions"
      v-model:open="showOptions"
      :title="t('common.cliOptions')"
      :dismissible="true"
      :ui="{ content: 'sm:max-w-6xl', body: 'p-0' }"
    >
      <template #description>
        <span class="sr-only">{{ t('common.browseYtdlpFlags') }}</span>
      </template>

      <template #body>
        <YTDLPOptions />
      </template>
    </UModal>

    <UModal
      v-model:open="showTestResults"
      :title="t('common.testResults')"
      :dismissible="true"
      :ui="{ content: 'sm:max-w-5xl', body: 'p-0' }"
      @update:open="(open) => !open && closeTestResults()"
    >
      <template #body>
        <div class="relative min-h-[40vh] p-4 sm:p-5">
          <div v-if="!testResultsData" class="flex min-h-[40vh] items-center justify-center">
            <UIcon
              name="i-lucide-loader-circle"
              class="size-16 animate-spin text-toned sm:size-20"
            />
          </div>

          <div v-else class="relative">
            <div class="pointer-events-none absolute right-3 top-3 z-10 flex items-center gap-2">
              <button
                type="button"
                class="pointer-events-auto inline-flex size-9 items-center justify-center rounded-md border border-default bg-default/90 text-toned shadow-sm transition-colors hover:text-default"
                :aria-label="t('common.toggleWrap')"
                @click="toggleTestResultsWrap"
              >
                <UIcon name="i-lucide-wrap-text" class="size-4" />
              </button>
              <button
                type="button"
                class="pointer-events-auto inline-flex size-9 items-center justify-center rounded-md border border-default bg-default/90 text-toned shadow-sm transition-colors hover:text-default"
                :aria-label="t('common.copyTextAria')"
                @click="copyTestResults"
              >
                <UIcon name="i-lucide-copy" class="size-4" />
              </button>
            </div>

            <pre
              :class="testResultsPreClasses"
              dir="ltr"
            ><code class="block p-4" v-text="testResultsText" /></pre>
          </div>
        </div>
      </template>
    </UModal>

    <PlaylistPicker
      v-if="showPlaylistPicker"
      :link="splitUrls(form.url || '')[0] || ''"
      :preset="form.preset"
      :cli="form.cli"
      @closeModel="() => void requestClosePlaylistPicker()"
      @dirty-change="playlistPickerDirty = $event"
      @picked="setPickedEntries"
    />
  </main>
</template>

<script setup lang="ts">
import { useStorage } from '@vueuse/core';
import TextareaAutocomplete from '~/components/TextareaAutocomplete.vue';
import TextDropzone from '~/components/TextDropzone.vue';
import PlaylistPicker from '~/components/PlaylistPicker.vue';
import { useConditions } from '~/composables/useConditions';
import { useDirtyCloseGuard } from '~/composables/useDirtyCloseGuard';
import type { Condition } from '~/types/conditions';
import type { download_form_item, item_request, picked_entry } from '~/types/item';
import type { TaskScheduleDraft, TaskScheduleMetadata } from '~/types/tasks';
import type { AutoCompleteOptions } from '~/types/autocomplete';
import { navigateTo } from '#app';
import { useDialog } from '~/composables/useDialog';
import { getSeparatorsName, parse_api_error, shortPath, splitSources } from '~/utils';
import { useFormHandoff } from '~/composables/useFormHandoff';

const { t } = useI18n();

const props = defineProps<{ item?: Partial<download_form_item> }>();
const emitter = defineEmits<{
  (e: 'getInfo', url: string, preset: string | undefined, cli: string | undefined): void;
  (e: 'clear_form'): void;
}>();
const config = useYtpConfig();
const toast = useNotification();
const dialog = useDialog();
const conditions = useConditions();
const tasksComposable = useTasks();
const { findPreset, hasPreset, selectItems, getPresetDefault } = usePresetOptions();

const showAdvanced = useStorage<boolean>('show_advanced', false);
const separator = useStorage<string>('url_separator', separators[0]?.value ?? ',');
const auto_start = useStorage<boolean>('auto_start', true);
const show_description = useStorage<boolean>('show_description', true);
const dlFields = useStorage<Record<string, any>>('dl_fields', {});
const storedCommand = useStorage<string>('console_command', '');
const testResultsClasses = useStorage<string>('modal_text_classes', '');

const addInProgress = ref<boolean>(false);
const scheduleInProgress = ref(false);
const submitError = ref('');
const showOptions = ref<boolean>(false);
const showTestResults = ref<boolean>(false);
const showPlaylistPicker = ref<boolean>(false);
const playlistPickerDirty = ref<boolean>(false);
const pickedEntries = ref<picked_entry[]>([]);
const applyingPickedEntries = ref(false);

const openPlaylistPicker = (): void => {
  showPlaylistPicker.value = true;
};

const setPickedEntries = (entries: picked_entry[]): void => {
  pickedEntries.value = entries;
  applyingPickedEntries.value = true;
  form.value.url = entries.map((entry) => entry.url).join('\n');
  applyingPickedEntries.value = false;
};

const clearPickedEntries = (): void => {
  if (applyingPickedEntries.value) return;
  pickedEntries.value = [];
};

const { requestClose: requestClosePlaylistPicker } = useDirtyCloseGuard(showPlaylistPicker, {
  dirty: playlistPickerDirty,
  preferenceKey: 'playlist-picker',
  onDiscard: () => {
    playlistPickerDirty.value = false;
  },
});
const testResultsData = ref<any>(null);
const dlFieldsExtra = ['--no-download-archive', '--no-continue'];
const ytDlpOpt = ref<AutoCompleteOptions>([]);
const cookiesDropzoneRef = ref<InstanceType<typeof TextDropzone> | null>(null);
const urlTextarea = ref<{ textareaRef?: HTMLTextAreaElement | null } | null>(null);

type IgnoreConditionOption = {
  value: string;
  label: string;
};

const normalizeIgnoreConditionValues = (value: unknown): string[] => {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map((entry) => {
      if ('boolean' === typeof entry) {
        return '';
      }

      if ('number' === typeof entry || 'string' === typeof entry) {
        return String(entry).trim();
      }

      return '';
    })
    .filter((entry, index, items) => !!entry && items.indexOf(entry) === index);
};

const buildIgnoreConditionOptions = (
  items: readonly Condition[],
  selectedValues: readonly string[] = [],
): IgnoreConditionOption[] => {
  const options = items
    .filter((condition) => condition.enabled)
    .map((condition) => ({
      value:
        condition.id !== undefined && condition.id !== null ? String(condition.id) : condition.name,
      label: condition.name,
    }));

  const missingSelectedItems = selectedValues
    .filter((value) => value !== '*' && !options.some((item) => item.value === value))
    .map((value) => ({
      value,
      label: value,
    }));

  return [
    {
      value: '*',
      label: t('common.allConditions'),
    },
    ...options,
    ...missingSelectedItems,
  ];
};

const mergeIgnoreConditionsIntoExtras = (
  extras: Record<string, unknown> | undefined,
  ignoreConditions: string[],
): Record<string, unknown> => {
  const nextExtras = { ...(extras || {}) };

  if (ignoreConditions.length > 0) {
    nextExtras.ignore_conditions = [...ignoreConditions];
    return nextExtras;
  }

  delete nextExtras.ignore_conditions;
  return nextExtras;
};

const hasAllConditionsLoaded = computed(() => {
  const loaded = conditions.conditions.value.length;
  const total = conditions.pagination.value.total;

  return loaded > 0 && (total <= 0 || loaded >= total);
});

const ensureIgnoreConditionsLoaded = async (): Promise<void> => {
  if (conditions.isLoading.value || hasAllConditionsLoaded.value) {
    return;
  }

  await conditions.loadConditions(1, 1000);
};

const selectedIgnoreConditions = computed<string[]>({
  get: () => normalizeIgnoreConditionValues(form.value?.extras?.ignore_conditions),
  set: (values) => {
    const extras = mergeIgnoreConditionsIntoExtras(
      form.value?.extras,
      normalizeIgnoreConditionValues(values),
    );
    form.value.extras = Object.keys(extras).length > 0 ? extras : {};
  },
});

const testResultsText = computed(() => {
  if (typeof testResultsData.value === 'string') {
    return testResultsData.value;
  }

  if (testResultsData.value === undefined || testResultsData.value === null) {
    return '';
  }

  try {
    return JSON.stringify(testResultsData.value, null, 2) ?? '';
  } catch {
    return String(testResultsData.value ?? '');
  }
});

const testResultsPreClasses = computed(() => [
  'max-h-[calc(100vh-10rem)] overflow-auto rounded-xl border border-default bg-elevated/40 text-sm text-default',
  'font-mono leading-6 whitespace-pre',
  testResultsClasses.value,
]);

const downloadFieldUi = {
  label: 'font-semibold text-default',
  container: 'space-y-2',
};

const advancedEditorFieldUi = {
  root: 'w-full',
  label: 'font-semibold text-default',
  container: 'space-y-2',
  description: 'text-sm text-toned',
  help: 'mt-2 text-sm text-toned',
};

const form = useStorage<item_request>('local_config_v1', {
  id: null,
  url: '',
  preset: config.app.default_preset,
  cookies: '',
  cli: '',
  template: '',
  folder: '',
  extras: {},
}) as Ref<item_request>;

const presetItems = computed(() => selectItems.value);
const ignoreConditionOptions = computed(() =>
  buildIgnoreConditionOptions(
    conditions.conditions.value,
    normalizeIgnoreConditionValues(form.value?.extras?.ignore_conditions),
  ),
);
const hasIgnoreConditionOptions = computed(() =>
  ignoreConditionOptions.value.some((option) => option.value !== '*'),
);

const mobileActionGroups = computed(() => {
  const groups = [
    [
      {
        label: t('common.customFieldsAction'),
        icon: 'i-lucide-plus',
        onSelect: () => navigateTo('/dl_fields'),
      },
      {
        label: t('common.ytdlpInformation'),
        icon: 'i-lucide-info',
        disabled: addInProgress.value || !hasSingleUrl.value,
        onSelect: () =>
          emitter(
            'getInfo',
            splitUrls(form.value.url || '')[0] || '',
            form.value.preset,
            form.value.cli,
          ),
      },
    ],
  ] as Array<Array<Record<string, unknown>>>;

  if (config.app.console_enabled) {
    groups[0]?.push(
      {
        label: t('common.runCli'),
        icon: 'i-lucide-terminal',
        disabled: !hasValidUrl.value,
        onSelect: () => void runCliCommand(),
      },
      {
        label: t('common.showCompiledOptions'),
        icon: 'i-lucide-flask-conical',
        disabled: !hasValidUrl.value,
        onSelect: () => void testDownloadOptions(),
      },
    );
  }

  groups.push([
    {
      label: t('common.resetLocalSettings'),
      icon: 'i-lucide-rotate-ccw',
      disabled: Boolean(form.value?.id),
      onSelect: () => void resetConfig(),
    },
  ]);

  return groups;
});

const downloadActionGroups = computed(() => [
  [
    {
      label: t('common.pickPlaylistVideos'),
      icon: 'i-lucide-list-video',
      disabled: addInProgress.value || !hasValidUrl.value,
      onSelect: openPlaylistPicker,
    },
    {
      label: t('tasks.schedule'),
      icon: 'i-lucide-calendar',
      disabled: addInProgress.value || scheduleInProgress.value || !hasSingleUrl.value,
      onSelect: () => void scheduleDownload(),
    },
  ],
]);

const taskFormHandoff = useFormHandoff<TaskScheduleDraft>('task');

const is_valid_dl_field = (dl_field: string): boolean => {
  if (dlFieldsExtra.includes(dl_field)) {
    return true;
  }

  if (config.dl_fields && config.dl_fields.length > 0) {
    return config.dl_fields.some((f) => f.field === dl_field);
  }

  return false;
};

const getUrlElement = (): HTMLInputElement | HTMLTextAreaElement | null => {
  return (
    urlTextarea.value?.textareaRef || (document.getElementById('url') as HTMLInputElement | null)
  );
};

const handleKeyDown = async (event: KeyboardEvent): Promise<void> => {
  const target = event.target as HTMLInputElement | HTMLTextAreaElement;
  const isTextarea = target.tagName === 'TEXTAREA';
  if (event.key !== 'Enter') {
    return;
  }

  if (event.ctrlKey && isTextarea && !hasValidUrl.value) {
    event.preventDefault();
    addDownload();
    return;
  }

  if (event.shiftKey && !isTextarea) {
    event.preventDefault();
    const cursorPos = target.selectionStart || form.value.url.length;
    form.value.url =
      form.value.url.substring(0, cursorPos) +
      '\n' +
      form.value.url.substring(target.selectionEnd || cursorPos);

    await nextTick();

    const field = getUrlElement();
    if (field instanceof HTMLTextAreaElement) {
      field.setSelectionRange(cursorPos + 1, cursorPos + 1);
      field.focus();
    }
  }
};

const handlePaste = async (event: ClipboardEvent): Promise<void> => {
  const pastedText = event.clipboardData?.getData('text') || '';
  if (!pastedText.includes('\n')) {
    return;
  }

  event.preventDefault();

  const target = event.target as HTMLInputElement;
  const currentValue = form.value.url || '';
  const start = target.selectionStart || currentValue.length;
  const end = target.selectionEnd || currentValue.length;
  form.value.url = currentValue.substring(0, start) + pastedText + currentValue.substring(end);

  await nextTick();

  const field = getUrlElement();
  if (field instanceof HTMLTextAreaElement) {
    const newPos = start + pastedText.length;
    field.setSelectionRange(newPos, newPos);
    field.focus();
  }
};

const splitUrls = (urlString: string): Array<string> => {
  return splitSources(urlString, separator.value);
};

const addDownload = async () => {
  submitError.value = '';
  if (form.value.folder) {
    form.value.folder = form.value.folder.trim();
  }

  let form_cli = (form.value?.cli || '').trim();

  if (dlFields.value && Object.keys(dlFields.value).length > 0) {
    const joined = [];
    for (const [key, value] of Object.entries(dlFields.value)) {
      if (false === is_valid_dl_field(key)) {
        continue;
      }

      if ([undefined, null, '', false].includes(value as any)) {
        continue;
      }

      const keyRegex = new RegExp(`(^|\\s)${key}(\\s|$)`);
      if (form_cli && keyRegex.test(form_cli)) {
        continue;
      }

      joined.push(true === value ? `${key}` : `${key} ${value}`);
    }

    if (joined.length > 0) {
      form_cli = form_cli ? `${form_cli} ${joined.join(' ')}` : joined.join(' ');
    }
  }

  if (form_cli && form_cli.trim()) {
    const options = await convertOptions(form_cli);
    if (null === options) {
      return;
    }
  }

  const request_data = [] as Array<item_request>;

  splitUrls(form.value.url).forEach((url: string, index: number) => {
    const data = {
      url: url,
      preset: form.value.preset || config.app.default_preset,
      folder: form.value.folder,
      template: form.value.template,
      cookies: form.value.cookies,
      cli: form_cli,
      auto_start: auto_start.value,
    } as item_request;

    const extras = {
      ...(form.value?.extras || {}),
      ...(pickedEntries.value[index]?.extras || {}),
    };
    if (Object.keys(extras).length > 0) {
      data.extras = extras;
    }

    request_data.push(data);
  });

  try {
    addInProgress.value = true;
    const response = await request('/api/history', {
      method: 'POST',
      body: JSON.stringify(request_data),
    });

    const data = await response.json();
    if (!response.ok) {
      submitError.value = (await parse_api_error(data)) || t('queue.failedToAdd');
      return;
    }

    let had_errors = false;
    const errors: string[] = [];

    if (200 === response.status) {
      data.forEach((item: Record<string, any>) => {
        if (false !== item.status) {
          return;
        }

        had_errors = true;

        if (item?.hidden) {
          return;
        }

        const message = t('common.errorPrefix', { msg: item.msg || t('queue.failedToAdd') });
        errors.push(message);
      });
    }

    submitError.value = errors.join('\n');

    if (202 === response.status) {
      toast.success(data.message, { timeout: 2000 });
    }

    if (false === had_errors) {
      form.value.url = '';
      pickedEntries.value = [];
      emitter('clear_form');
    }
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : t('queue.failedToAdd');
    submitError.value = t('common.errorPrefix', { msg: message });
  } finally {
    addInProgress.value = false;
  }
};

const resetConfig = async () => {
  const { status } = await dialog.confirmDialog({
    title: t('common.pleaseConfirm'),
    message: t('common.confirmResetConfig'),
    confirmColor: 'error',
  });
  if (!status) {
    return;
  }

  form.value = {
    url: '',
    preset: config.app.default_preset,
    cookies: '',
    cli: '',
    template: '',
    folder: '',
    extras: {},
  } as item_request;
  pickedEntries.value = [];
  dlFields.value = {};
  showAdvanced.value = false;
  toast.success(t('common.resetConfigDone'));
};

const convertOptions = async (args: string) => {
  try {
    const response = await convertCliOptions(args);

    if (response.output_template) {
      form.value.template = response.output_template;
    }

    if (response.download_path) {
      form.value.folder = response.download_path;
    }

    return response.opts;
  } catch (error) {
    submitError.value = error instanceof Error ? error.message : t('common.unknownError');
  }

  return null;
};

onUpdated(async () => {
  await nextTick();

  if ('' === form.value?.preset) {
    form.value.preset = config.app.default_preset;
  }

  if (config.isLoaded() && form.value?.preset && !hasPreset(form.value.preset)) {
    form.value.preset = config.app.default_preset;
  }
});

watch(
  () => config.ytdlp_options,
  (newOptions) =>
    (ytDlpOpt.value = newOptions
      .filter((opt) => !opt.ignored)
      .flatMap((opt) =>
        opt.flags
          .filter((flag) => flag.startsWith('--'))
          .map((flag) => ({ value: flag, description: opt.description || '' })),
      )),
  { immediate: true },
);

watch(
  showAdvanced,
  (open) => {
    if (!open) {
      return;
    }

    void ensureIgnoreConditionsLoaded();
  },
  { immediate: true },
);

onMounted(async () => {
  await nextTick();

  if ('' === form.value?.preset) {
    form.value.preset = config.app.default_preset;
  }

  if (form.value?.folder) {
    form.value.folder = form.value.folder.trim();
    await nextTick();
  }

  if (config.isLoaded() && form.value?.preset && !hasPreset(form.value.preset)) {
    form.value.preset = config.app.default_preset;
  }

  if (props?.item) {
    pickedEntries.value = props.item.picked_entries
      ? JSON.parse(JSON.stringify(props.item.picked_entries))
      : [];
    if (typeof props.item.auto_start === 'boolean') auto_start.value = props.item.auto_start;
    const updates: Partial<item_request> = {};
    const keys = Object.keys(props.item).filter(
      (key) => key !== 'picked_entries',
    ) as (keyof item_request)[];
    for (const key of keys) {
      const value = props.item[key];
      updates[key] = key === 'extras' ? JSON.parse(JSON.stringify(value)) : value!;
    }
    form.value = { ...form.value, ...updates };
    emitter('clear_form');
  }

  await nextTick();

  if (!separators.some((s) => s.value === separator.value)) {
    separator.value = separators[0]?.value ?? ',';
  }
});

const runCliCommand = async (): Promise<void> => {
  submitError.value = '';
  if (!form.value.url) {
    toast.warning(t('common.enterUrlFirst'));
    return;
  }

  if (form.value?.folder) {
    form.value.folder = form.value.folder.trim();
    await nextTick();
  }

  const { status } = await dialog.confirmDialog({
    title: t('common.confirmRunCliTitle'),
    message: t('common.confirmRunCliDesc'),
  });

  if (!status) {
    return;
  }

  let form_cli = (form.value?.cli || '').trim();

  if (dlFields.value && Object.keys(dlFields.value).length > 0) {
    const joined = [];
    for (const [key, value] of Object.entries(dlFields.value)) {
      if (false === is_valid_dl_field(key)) {
        continue;
      }

      if ([undefined, null, '', false].includes(value as any)) {
        continue;
      }

      const keyRegex = new RegExp(`(^|\\s)${key}(\\s|$)`);
      if (form_cli && keyRegex.test(form_cli)) {
        continue;
      }

      joined.push(true === value ? `${key}` : `${key} ${value}`);
    }

    if (joined.length > 0) {
      form_cli = form_cli ? `${form_cli} ${joined.join(' ')}` : joined.join(' ');
    }
  }

  if (form_cli && form_cli.trim()) {
    const options = await convertOptions(form_cli);
    if (null === options) {
      return;
    }
  }

  try {
    const resp = await request('/api/yt-dlp/command', {
      method: 'POST',
      body: JSON.stringify({
        url: splitUrls(form.value.url).join(' '),
        preset: form.value.preset,
        folder: form.value.folder,
        cookies: form.value.cookies,
        template: form.value.template,
        cli: form_cli,
      }),
    });

    const json = (await resp.json()) as { command?: string; error?: string };

    if (!resp.ok) {
      submitError.value = await parse_api_error(json);
      return;
    }

    storedCommand.value = json.command;

    await nextTick();
    await navigateTo('/console');
  } catch (error) {
    submitError.value = error instanceof Error ? error.message : t('common.failedCreateCommand');
  }
};

const testDownloadOptions = async (): Promise<void> => {
  submitError.value = '';
  if (!form.value.url) {
    toast.warning(t('common.enterUrlFirst'));
    return;
  }

  if (form.value?.folder) {
    form.value.folder = form.value.folder.trim();
    await nextTick();
  }

  let form_cli = (form.value?.cli || '').trim();

  if (dlFields.value && Object.keys(dlFields.value).length > 0) {
    const joined = [];
    for (const [key, value] of Object.entries(dlFields.value)) {
      if (false === is_valid_dl_field(key)) {
        continue;
      }

      if ([undefined, null, '', false].includes(value as any)) {
        continue;
      }

      const keyRegex = new RegExp(`(^|\\s)${key}(\\s|$)`);
      if (form_cli && keyRegex.test(form_cli)) {
        continue;
      }

      joined.push(true === value ? `${key}` : `${key} ${value}`);
    }

    if (joined.length > 0) {
      form_cli = form_cli ? `${form_cli} ${joined.join(' ')}` : joined.join(' ');
    }
  }

  try {
    const resp = await request('/api/yt-dlp/command?full=true', {
      method: 'POST',
      body: JSON.stringify({
        url: form.value.url,
        preset: form.value.preset,
        folder: form.value.folder,
        cookies: form.value.cookies,
        template: form.value.template,
        cli: form_cli,
      }),
    });

    const json = await resp.json();

    if (!resp.ok) {
      submitError.value = await parse_api_error(json);
      return;
    }

    testResultsData.value = {
      command: json.command,
      yt_dlp: json.ytdlp,
    };
    showTestResults.value = true;
  } catch (error) {
    submitError.value = error instanceof Error ? error.message : t('common.failedTestOptions');
  }
};

const closeTestResults = () => {
  showTestResults.value = false;
  testResultsData.value = null;
};

const toggleTestResultsWrap = () => {
  if (testResultsClasses.value.includes('is-pre-wrap-force')) {
    testResultsClasses.value = testResultsClasses.value.replace('is-pre-wrap-force', '').trim();
    return;
  }

  testResultsClasses.value = `${testResultsClasses.value} is-pre-wrap-force`.trim();
};

const copyTestResults = () => {
  try {
    copyText(JSON.stringify(testResultsData.value, null, 2));
  } catch {
    copyText(testResultsText.value);
  }
};

const isMultiLineInput = computed(() => !!form.value.url && form.value.url.includes('\n'));
const hasFormatInConfig = computed(
  (): boolean => !!form.value.cli?.match(/(?<!\S)(-f|--format)(=|\s)(\S+)/),
);

const expand_description = (e: Event) =>
  toggleClass(e.target as HTMLElement, ['is-ellipsis', 'is-pre-wrap']);

const getDefault = (type: 'cookies' | 'cli' | 'template' | 'folder', ret: string = '') => {
  if (false !== hasFormatInConfig.value || !form.value.preset) {
    return ret;
  }

  return getPresetDefault(form.value.preset, type, ret);
};

const sortedDLFields = computed(() =>
  [...config.dl_fields].sort((a, b) => (a.order || 0) - (b.order || 0)),
);
const hasValidUrl = computed(() => form.value.url && form.value.url.trim().length > 0);
const hasSingleUrl = computed(() => splitUrls(form.value.url || '').length === 1);

const scheduleDownload = async (): Promise<void> => {
  if (addInProgress.value || scheduleInProgress.value || !hasSingleUrl.value) {
    return;
  }

  const url = splitUrls(form.value.url || '')[0];
  if (!url) {
    return;
  }

  scheduleInProgress.value = true;
  let metadata: TaskScheduleMetadata = {};
  try {
    const params = new URLSearchParams({
      url,
      preset: form.value.preset || config.app.default_preset,
      args: '-I0',
    });
    const response = await request(`/api/yt-dlp/url/info?${params.toString()}`);
    if (!response.ok) {
      throw new Error('Metadata request failed');
    }
    metadata = (await response.json()) as typeof metadata;
    if (!tasksComposable.isTaskSource(metadata)) {
      await dialog.alertDialog({
        message: t('tasks.schedulePlaylistOnly'),
        confirmText: t('common.ok'),
        confirmColor: 'warning',
      });
      return;
    }

    const hasTitle = [metadata.title, metadata.fulltitle].some(
      (value) => typeof value === 'string' && value.trim(),
    );
    if (!hasTitle) {
      toast.warning(t('common.failedGenerateMetadata'));
    }
  } catch (error) {
    console.error(error);
    toast.warning(t('common.failedGenerateMetadata'));
  } finally {
    scheduleInProgress.value = false;
  }

  taskFormHandoff.set(
    tasksComposable.createTaskDraft(metadata, {
      url,
      preset: form.value.preset || config.app.default_preset,
      folder: form.value.folder || '',
      template: form.value.template || '',
      cli: form.value.cli || '',
      ignore_conditions: normalizeIgnoreConditionValues(form.value.extras?.ignore_conditions),
    }),
  );
  await navigateTo('/tasks');
};

watch(isMultiLineInput, async (newValue) => {
  await nextTick();
  if (newValue) {
    urlTextarea.value?.textareaRef?.focus();
    return;
  }
  getUrlElement()?.focus();
});
</script>
